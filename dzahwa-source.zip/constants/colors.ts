/**
 * Semantic design tokens for the mobile app.
 *
 * These tokens mirror the naming conventions used in web artifacts (index.css)
 * so that multi-artifact projects share a cohesive visual identity.
 *
 * Replace the placeholder values below with values that match the project's
 * brand. If a sibling web artifact exists, read its index.css and convert the
 * HSL values to hex so both artifacts use the same palette.
 *
 * To add dark mode, add a `dark` key with the same token names.
 * The useColors() hook will automatically pick it up.
 */

const colors = {
  light: {
    // Legacy aliases (kept for backward compatibility)
    text: '#241A1A',
    tint: '#8C2433',

    // Core surfaces
    background: '#F8F3ED',
    foreground: '#241A1A',

    // Cards / elevated surfaces
    card: '#FFFDFC',
    cardForeground: '#241A1A',

    // Primary action color (buttons, links, active states)
    primary: '#8C2433',
    primaryForeground: '#ffffff',

    // Secondary / less-emphasis interactive surfaces
    secondary: '#EFE3D6',
    secondaryForeground: '#5D3D35',

    // Muted / subdued elements (dividers, timestamps, placeholders)
    muted: '#E9DED1',
    mutedForeground: '#806E66',

    // Accent highlights (badges, selected items, focus rings)
    accent: '#D9A441',
    accentForeground: '#4A3219',

    // Destructive actions (delete, error states)
    destructive: '#ef4444',
    destructiveForeground: '#ffffff',

    // Borders and input outlines
    border: '#E3D4C7',
    input: '#D8C5B8',

    // Brand surfaces
    ink: '#241A1A',
    burgundy: '#8C2433',
    burgundyDark: '#6E1D29',
    cream: '#F8F3ED',
    sand: '#E7D5C1',
    gold: '#D9A441',
    sage: '#718071',
  },

  // Border radius (in px). Sync from the sibling web artifact's --radius
  // CSS variable. This value applies to cards, buttons, inputs, and modals.
  radius: 8,
};

export default colors;

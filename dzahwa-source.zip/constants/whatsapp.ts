export const WHATSAPP_BUSINESS_NUMBER_STORAGE_KEY =
  '@dzahwa-collections/whatsapp-business-number';
export const DEFAULT_WHATSAPP_BUSINESS_NUMBER = '6282244757233';

export const normalizeWhatsAppNumber = (value: string) => {
  const digits = value.replace(/\D/g, '');
  if (digits.startsWith('0')) {
    return `62${digits.slice(1)}`;
  }
  if (digits.startsWith('8')) {
    return `62${digits}`;
  }
  return digits;
};

export const isValidWhatsAppNumber = (value: string) =>
  /^628\d{8,11}$/.test(normalizeWhatsAppNumber(value));

export const formatWhatsAppNumber = (value: string) => {
  const normalized = normalizeWhatsAppNumber(value);
  const localNumber = normalized.startsWith('62') ? `0${normalized.slice(2)}` : normalized;
  return localNumber.replace(/^(\d{4})(\d{4})(\d+)$/, '$1 $2 $3');
};
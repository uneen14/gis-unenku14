export type OrderDraft = {
  activeCategoryId: string;
  activeSizeIndex: number;
  selectedItemIndex: number;
  designDescription: string;
  designPosition: string;
  shirtColor: string;
  sizeQuantities: Record<string, string>;
  neededDate: string;
  destinationCity: string;
};

export type OrderDraftStorage = {
  getItem: (key: string) => Promise<string | null>;
  setItem: (key: string, value: string) => Promise<void>;
};

export const ORDER_DRAFT_STORAGE_KEY = '@dzahwa-collections/order-draft';
export const getDefaultOrderDraft = (): OrderDraft => ({
  activeCategoryId: 'dewasa',
  activeSizeIndex: 1,
  selectedItemIndex: 0,
  designDescription: '',
  designPosition: 'Depan',
  shirtColor: 'Hitam',
  sizeQuantities: { S: '1' },
  neededDate: '',
  destinationCity: '',
});

const errorMessage = (error: unknown) =>
  error instanceof Error ? error.message : String(error);

const isStringRecord = (value: unknown): value is Record<string, string> =>
  typeof value === 'object' &&
  value !== null &&
  !Array.isArray(value) &&
  Object.values(value).every((entry) => typeof entry === 'string');

const isOrderDraft = (value: unknown): value is OrderDraft => {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) {
    return false;
  }

  const draft = value as Partial<OrderDraft>;
  return (
    typeof draft.activeCategoryId === 'string' &&
    typeof draft.activeSizeIndex === 'number' &&
    Number.isInteger(draft.activeSizeIndex) &&
    typeof draft.selectedItemIndex === 'number' &&
    Number.isInteger(draft.selectedItemIndex) &&
    typeof draft.designDescription === 'string' &&
    typeof draft.designPosition === 'string' &&
    typeof draft.shirtColor === 'string' &&
    isStringRecord(draft.sizeQuantities) &&
    typeof draft.neededDate === 'string' &&
    typeof draft.destinationCity === 'string'
  );
};

export async function readOrderDraft(
  storage: OrderDraftStorage,
  defaults: OrderDraft,
): Promise<OrderDraft> {
  let storedDraft: string | null;

  try {
    storedDraft = await storage.getItem(ORDER_DRAFT_STORAGE_KEY);
  } catch (error) {
    throw new Error(`Tidak dapat membaca draft pesanan: ${errorMessage(error)}`);
  }

  if (!storedDraft) {
    return defaults;
  }

  try {
    const parsed: unknown = JSON.parse(storedDraft);
    if (!isOrderDraft(parsed)) {
      throw new Error('format draft pesanan tidak valid');
    }
    return parsed;
  } catch (error) {
    throw new Error(`Tidak dapat membaca draft pesanan: ${errorMessage(error)}`);
  }
}

export async function writeOrderDraft(
  storage: OrderDraftStorage,
  draft: OrderDraft,
): Promise<void> {
  try {
    await storage.setItem(ORDER_DRAFT_STORAGE_KEY, JSON.stringify(draft));
  } catch (error) {
    throw new Error(`Tidak dapat menyimpan draft pesanan: ${errorMessage(error)}`);
  }
}

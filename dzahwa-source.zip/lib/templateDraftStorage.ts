export type TemplateDrafts = Record<string, string>;

export type TemplateDraftStorage = {
  getItem: (key: string) => Promise<string | null>;
  setItem: (key: string, value: string) => Promise<void>;
};

export const TEMPLATE_DRAFTS_STORAGE_KEY = '@dzahwa-collections/template-drafts';

const errorMessage = (error: unknown) =>
  error instanceof Error ? error.message : String(error);

const isStoredTemplateDrafts = (value: unknown): value is TemplateDrafts =>
  typeof value === 'object' &&
  value !== null &&
  !Array.isArray(value) &&
  Object.values(value).every((draft) => typeof draft === 'string');

export async function readTemplateDrafts(
  storage: TemplateDraftStorage,
  defaults: TemplateDrafts,
): Promise<TemplateDrafts> {
  let storedDrafts: string | null;

  try {
    storedDrafts = await storage.getItem(TEMPLATE_DRAFTS_STORAGE_KEY);
  } catch (error) {
    throw new Error(
      `Tidak dapat membaca draft template dari penyimpanan lokal: ${errorMessage(error)}`,
    );
  }

  if (!storedDrafts) {
    return defaults;
  }

  try {
    const parsedDrafts: unknown = JSON.parse(storedDrafts);
    if (!isStoredTemplateDrafts(parsedDrafts)) {
      throw new Error('format data draft tidak valid');
    }

    return { ...defaults, ...parsedDrafts };
  } catch (error) {
    throw new Error(
      `Tidak dapat membaca draft template dari penyimpanan lokal: ${errorMessage(error)}`,
    );
  }
}

export async function writeTemplateDrafts(
  storage: TemplateDraftStorage,
  drafts: TemplateDrafts,
): Promise<void> {
  try {
    await storage.setItem(
      TEMPLATE_DRAFTS_STORAGE_KEY,
      JSON.stringify(drafts),
    );
  } catch (error) {
    throw new Error(
      `Tidak dapat menyimpan draft template ke penyimpanan lokal: ${errorMessage(error)}`,
    );
  }
}
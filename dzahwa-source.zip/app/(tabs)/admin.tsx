import AsyncStorage from '@react-native-async-storage/async-storage';
import { Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { useCallback, useEffect, useState } from 'react';
import { useFocusEffect } from 'expo-router';
import {
  Alert,
  Pressable,
  ScrollView,
  Share,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';
import {
  DEFAULT_WHATSAPP_BUSINESS_NUMBER,
  formatWhatsAppNumber,
  isValidWhatsAppNumber,
  normalizeWhatsAppNumber,
  WHATSAPP_BUSINESS_NUMBER_STORAGE_KEY,
} from '@/constants/whatsapp';

type AdminTemplate = {
  id: string;
  shortcut: string;
  title: string;
  message: string;
};

const templates: AdminTemplate[] = [
  { id: 'salam', shortcut: '/salam', title: 'Menyambut pelanggan', message: 'Halo! Terima kasih sudah menghubungi D’Zahwa Collections 👕 Kami melayani kaos custom anak dan dewasa dengan foto, tulisan, atau logo. Ada desain yang ingin dibuat?' },
  { id: 'format', shortcut: '/format', title: 'Meminta detail pesanan', message: 'Agar kami bisa bantu cek pesanan, mohon kirim:\n• Foto/logo/tulisan untuk desain\n• Warna kaos\n• Ukuran dan jumlah masing-masing\n• Posisi desain: depan, belakang, atau keduanya\n• Tanggal dibutuhkan\n• Kota tujuan pengiriman' },
  { id: 'harga', shortcut: '/harga', title: 'Menjawab pertanyaan harga', message: 'Harga kaos custom bergantung pada ukuran, jumlah, dan penempatan desain. Kirim ukuran serta desain yang diinginkan, ya. Setelah itu kami buatkan rincian harga sebelum pesanan diproses.' },
  { id: 'desain', shortcut: '/desain', title: 'Memastikan desain', message: 'Mohon periksa kembali contoh desain yang kami kirim, terutama ejaan nama/tulisan, warna, dan posisi gambar. Jika semuanya sudah sesuai, balas DESAIN SETUJU.' },
  { id: 'total', shortcut: '/total', title: 'Mengirim rincian pesanan', message: 'Rincian pesanan Anda:\nDesain: [isi]\nWarna: [isi]\nUkuran dan jumlah: [isi]\nPosisi sablon: [isi]\nHarga kaos: Rp[isi]\nOngkir: Rp[isi]\nTotal: Rp[isi]\nPerkiraan selesai: [isi]\n\nMohon periksa rinciannya. Jika sudah sesuai, balas PESANAN SETUJU.' },
  { id: 'proses', shortcut: '/proses', title: 'Memberi kabar pesanan', message: 'Halo! Pesanan D’Zahwa Collections Anda saat ini sedang [tahap pesanan]. Kami akan mengabari Anda lagi saat [tahap berikutnya]. Terima kasih sudah menunggu 🙏' },
  { id: 'kirim', shortcut: '/kirim', title: 'Mengirim resi', message: 'Pesanan Anda sudah dikirim 📦\nKurir: [nama kurir]\nNomor resi: [nomor resi]\n\nTerima kasih sudah memesan di D’Zahwa Collections. Semoga kaosnya cocok dan nyaman dipakai!' },
  { id: 'terimakasih', shortcut: '/terimakasih', title: 'Setelah pesanan selesai', message: 'Terima kasih sudah memesan kaos custom di D’Zahwa Collections 👕💛\n\nSemoga kaosnya cocok dan nyaman dipakai. Kalau sudah diterima, kami senang sekali mendengar pendapat Anda. Sampai bertemu di pesanan berikutnya!' },
];

const STORAGE_KEY = '@dzahwa-collections/template-drafts';

export default function AdminScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [selectedId, setSelectedId] = useState('salam');
  const [drafts, setDrafts] = useState<Record<string, string>>(
    () => Object.fromEntries(templates.map((template) => [template.id, template.message])),
  );
  const [loaded, setLoaded] = useState(false);
  const [whatsappNumber, setWhatsappNumber] = useState(DEFAULT_WHATSAPP_BUSINESS_NUMBER);
  const [whatsappNumberInput, setWhatsappNumberInput] = useState(
    formatWhatsAppNumber(DEFAULT_WHATSAPP_BUSINESS_NUMBER),
  );
  const selected = templates.find((template) => template.id === selectedId) ?? templates[0];

  useEffect(() => {
    AsyncStorage.getItem(STORAGE_KEY)
      .then((stored) => {
        if (stored) {
          const parsed: unknown = JSON.parse(stored);
          if (typeof parsed === 'object' && parsed !== null && !Array.isArray(parsed)) {
            setDrafts((current) => ({ ...current, ...(parsed as Record<string, string>) }));
          }
        }
      })
      .catch(() => undefined)
      .finally(() => setLoaded(true));
  }, []);

  useEffect(() => {
    if (loaded) {
      void AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(drafts));
    }
  }, [drafts, loaded]);

  const loadWhatsAppNumber = useCallback(async () => {
    try {
      const storedNumber = await AsyncStorage.getItem(WHATSAPP_BUSINESS_NUMBER_STORAGE_KEY);
      if (storedNumber && isValidWhatsAppNumber(storedNumber)) {
        const normalized = normalizeWhatsAppNumber(storedNumber);
        setWhatsappNumber(normalized);
        setWhatsappNumberInput(formatWhatsAppNumber(normalized));
      }
    } catch {
      Alert.alert('Pengaturan belum termuat', 'Nomor WhatsApp Business masih menggunakan nomor sebelumnya.');
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      void loadWhatsAppNumber();
    }, [loadWhatsAppNumber]),
  );

  const shareSelected = async () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    await Share.share({ message: drafts[selected.id] });
  };

  const saveWhatsAppNumber = async () => {
    const normalized = normalizeWhatsAppNumber(whatsappNumberInput);
    if (!isValidWhatsAppNumber(normalized)) {
      Alert.alert(
        'Nomor tidak valid',
        'Gunakan nomor seluler WhatsApp Indonesia, misalnya 0822 4475 7233 atau +62 822 4475 7233.',
      );
      return;
    }

    try {
      await AsyncStorage.setItem(WHATSAPP_BUSINESS_NUMBER_STORAGE_KEY, normalized);
      setWhatsappNumber(normalized);
      setWhatsappNumberInput(formatWhatsAppNumber(normalized));
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      Alert.alert('Nomor tersimpan', 'Nomor baru akan dipakai untuk pesanan, panduan, dan kirim template.');
    } catch {
      Alert.alert('Nomor belum tersimpan', 'Coba lagi setelah ruang penyimpanan perangkat tersedia.');
    }
  };

  const restoreSelected = () => {
    Alert.alert(
      'Pulihkan pintasan ini?',
      `Isi ${selected.shortcut} akan dikembalikan ke teks bawaan.`,
      [
        { text: 'Batal', style: 'cancel' },
        {
          text: 'Pulihkan',
          onPress: () => {
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
            setDrafts((current) => ({ ...current, [selected.id]: selected.message }));
          },
        },
      ],
    );
  };

  const restoreAll = () => {
    Alert.alert(
      'Pulihkan semua template?',
      'Semua perubahan lokal pada 8 template akan dihapus dan diganti teks bawaan.',
      [
        { text: 'Batal', style: 'cancel' },
        {
          text: 'Pulihkan semua',
          style: 'destructive',
          onPress: () => {
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
            setDrafts(Object.fromEntries(templates.map((template) => [template.id, template.message])));
          },
        },
      ],
    );
  };

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      <ScrollView
        contentContainerStyle={[styles.content, { paddingTop: insets.top + 18, paddingBottom: insets.bottom + 94 }]}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.header}>
          <View style={styles.headerCopy}>
            <Text style={[styles.eyebrow, { color: colors.burgundy }]}>RUANG PEMILIK</Text>
            <Text style={[styles.title, { color: colors.ink }]}>Bantu pelanggan lebih cepat</Text>
            <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
              Kelola balasan WhatsApp dan sesuaikan placeholder sebelum dikirim.
            </Text>
          </View>
          <View style={[styles.headerIcon, { backgroundColor: colors.ink }]}>
            <Feather name="briefcase" size={20} color={colors.gold} />
          </View>
        </View>

        <View style={[styles.statusCard, { backgroundColor: colors.secondary }]}>
          <View style={[styles.statusIcon, { backgroundColor: colors.cream }]}>
            <Feather name="check-circle" size={18} color={colors.burgundy} />
          </View>
          <View style={styles.statusCopy}>
            <Text style={[styles.statusTitle, { color: colors.ink }]}>8 template siap dipakai</Text>
            <Text style={[styles.statusText, { color: colors.mutedForeground }]}>Draft otomatis tersimpan di perangkat ini.</Text>
          </View>
        </View>

        <View style={[styles.settingsCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={styles.settingsHeader}>
            <View style={[styles.settingsIcon, { backgroundColor: colors.secondary }]}>
              <Feather name="phone" size={18} color={colors.burgundy} />
            </View>
            <View style={styles.settingsCopy}>
              <Text style={[styles.settingsEyebrow, { color: colors.burgundy }]}>PENGATURAN KONTAK</Text>
              <Text style={[styles.settingsTitle, { color: colors.ink }]}>WhatsApp Business</Text>
              <Text style={[styles.settingsText, { color: colors.mutedForeground }]}>
                Nomor ini dipakai untuk pesanan, panduan, dan template.
              </Text>
            </View>
          </View>
          <TextInput
            testID="admin-whatsapp-number-input"
            value={whatsappNumberInput}
            onChangeText={setWhatsappNumberInput}
            keyboardType="phone-pad"
            placeholder="0822 4475 7233"
            placeholderTextColor={colors.mutedForeground}
            style={[styles.numberInput, { color: colors.ink, borderColor: colors.border, backgroundColor: colors.background }]}
          />
          <Text style={[styles.numberHint, { color: colors.mutedForeground }]}>
            Format yang diterima: 08..., 8..., atau +62....
          </Text>
          <Pressable
            testID="save-admin-whatsapp-number"
            onPress={() => {
              void saveWhatsAppNumber();
            }}
            style={({ pressed }) => [
              styles.saveNumberButton,
              { backgroundColor: colors.burgundy, opacity: pressed ? 0.82 : 1 },
            ]}
          >
            <Feather name="save" size={17} color={colors.gold} />
            <Text style={[styles.saveNumberText, { color: colors.cream }]}>Simpan nomor</Text>
            <Text style={[styles.savedNumber, { color: colors.sand }]}>{formatWhatsAppNumber(whatsappNumber)}</Text>
          </Pressable>
        </View>

        <View style={styles.sectionHeader}>
          <View>
            <Text style={[styles.eyebrow, { color: colors.burgundy }]}>BALASAN CEPAT</Text>
            <Text style={[styles.sectionTitle, { color: colors.ink }]}>Pilih pintasan</Text>
          </View>
          <Text style={[styles.count, { color: colors.mutedForeground }]}>WhatsApp Business</Text>
        </View>

        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.chips}>
          {templates.map((template) => {
            const isActive = template.id === selected.id;
            return (
              <Pressable
                key={template.id}
                testID={`admin-template-${template.id}`}
                onPress={() => {
                  Haptics.selectionAsync();
                  setSelectedId(template.id);
                }}
                style={({ pressed }) => [
                  styles.chip,
                  {
                    backgroundColor: isActive ? colors.burgundy : colors.card,
                    borderColor: isActive ? colors.burgundy : colors.border,
                    opacity: pressed ? 0.75 : 1,
                  },
                ]}
              >
                <Text style={[styles.chipShortcut, { color: isActive ? colors.gold : colors.burgundy }]}>{template.shortcut}</Text>
                <Text style={[styles.chipTitle, { color: isActive ? colors.cream : colors.ink }]}>{template.title}</Text>
              </Pressable>
            );
          })}
        </ScrollView>

        <View style={[styles.editorCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={styles.editorHeader}>
            <View>
              <Text style={[styles.editorShortcut, { color: colors.burgundy }]}>{selected.shortcut}</Text>
              <Text style={[styles.editorTitle, { color: colors.ink }]}>{selected.title}</Text>
            </View>
            <Feather name="edit-3" size={18} color={colors.burgundy} />
          </View>
          <TextInput
            testID="admin-template-editor"
            multiline
            textAlignVertical="top"
            value={drafts[selected.id]}
            onChangeText={(value) => setDrafts((current) => ({ ...current, [selected.id]: value }))}
            selectionColor={colors.burgundy}
            style={[styles.editor, { color: colors.ink, borderColor: colors.border }]}
          />
          <Text style={[styles.hint, { color: colors.mutedForeground }]}>
            Edit teks atau placeholder dalam kurung siku, lalu bagikan ke WhatsApp Business.
          </Text>
          <View style={styles.restoreRow}>
            <Pressable
              testID="admin-restore-selected"
              onPress={restoreSelected}
              style={({ pressed }) => [
                styles.restoreButton,
                { borderColor: colors.border, backgroundColor: colors.background, opacity: pressed ? 0.72 : 1 },
              ]}
            >
              <Feather name="rotate-ccw" size={15} color={colors.burgundy} />
              <Text style={[styles.restoreButtonText, { color: colors.burgundy }]}>Pulihkan ini</Text>
            </Pressable>
            <Pressable
              testID="admin-restore-all"
              onPress={restoreAll}
              style={({ pressed }) => [
                styles.restoreButton,
                { borderColor: colors.border, backgroundColor: colors.background, opacity: pressed ? 0.72 : 1 },
              ]}
            >
              <Feather name="refresh-cw" size={15} color={colors.burgundy} />
              <Text style={[styles.restoreButtonText, { color: colors.burgundy }]}>Pulihkan semua</Text>
            </Pressable>
          </View>
        </View>

        <Pressable
          testID="admin-share-button"
          onPress={shareSelected}
          style={({ pressed }) => [
            styles.shareButton,
            { backgroundColor: colors.burgundy, opacity: pressed ? 0.82 : 1 },
          ]}
        >
          <Feather name="share-2" size={18} color={colors.gold} />
          <Text style={[styles.shareText, { color: colors.cream }]}>Bagikan template</Text>
          <Feather name="arrow-up-right" size={18} color={colors.gold} />
        </Pressable>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  content: { paddingHorizontal: 20, gap: 18 },
  header: { flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between' },
  headerCopy: { flex: 1, paddingRight: 12 },
  eyebrow: { fontFamily: 'Inter_700Bold', fontSize: 10, letterSpacing: 1.45, marginBottom: 5 },
  title: { fontFamily: 'Inter_700Bold', fontSize: 27, lineHeight: 31, letterSpacing: -1 },
  subtitle: { fontFamily: 'Inter_400Regular', fontSize: 12, lineHeight: 18, marginTop: 5 },
  headerIcon: { width: 44, height: 44, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },
  statusCard: { borderRadius: 20, padding: 14, flexDirection: 'row', alignItems: 'center', gap: 11 },
  statusIcon: { width: 41, height: 41, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  statusCopy: { flex: 1 },
  statusTitle: { fontFamily: 'Inter_700Bold', fontSize: 14 },
  statusText: { fontFamily: 'Inter_400Regular', fontSize: 10, marginTop: 3 },
  settingsCard: { borderRadius: 21, borderWidth: 1, padding: 14, gap: 10 },
  settingsHeader: { flexDirection: 'row', alignItems: 'center', gap: 11 },
  settingsIcon: { width: 42, height: 42, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  settingsCopy: { flex: 1 },
  settingsEyebrow: { fontFamily: 'Inter_700Bold', fontSize: 9, letterSpacing: 1.15 },
  settingsTitle: { fontFamily: 'Inter_700Bold', fontSize: 15, marginTop: 3 },
  settingsText: { fontFamily: 'Inter_400Regular', fontSize: 10, lineHeight: 15, marginTop: 3 },
  numberInput: { minHeight: 46, borderRadius: 13, borderWidth: 1, paddingHorizontal: 12, fontFamily: 'Inter_600SemiBold', fontSize: 13 },
  numberHint: { fontFamily: 'Inter_400Regular', fontSize: 10, lineHeight: 14 },
  saveNumberButton: { minHeight: 48, borderRadius: 15, paddingHorizontal: 13, flexDirection: 'row', alignItems: 'center', gap: 8 },
  saveNumberText: { flex: 1, fontFamily: 'Inter_700Bold', fontSize: 12 },
  savedNumber: { fontFamily: 'Inter_500Medium', fontSize: 10 },
  sectionHeader: { flexDirection: 'row', alignItems: 'flex-end', justifyContent: 'space-between' },
  sectionTitle: { fontFamily: 'Inter_700Bold', fontSize: 21, letterSpacing: -0.7 },
  count: { fontFamily: 'Inter_500Medium', fontSize: 10, marginBottom: 3 },
  chips: { gap: 8, paddingRight: 20 },
  chip: { minWidth: 108, maxWidth: 132, minHeight: 67, borderRadius: 15, borderWidth: 1, padding: 10, justifyContent: 'space-between' },
  chipShortcut: { fontFamily: 'Inter_700Bold', fontSize: 11 },
  chipTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 11, lineHeight: 14 },
  editorCard: { borderRadius: 21, borderWidth: 1, padding: 14 },
  editorHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 10 },
  editorShortcut: { fontFamily: 'Inter_700Bold', fontSize: 11, letterSpacing: 0.4 },
  editorTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 15, marginTop: 3 },
  editor: { minHeight: 245, borderWidth: 1, borderRadius: 14, padding: 12, fontFamily: 'Inter_400Regular', fontSize: 13, lineHeight: 20 },
  hint: { fontFamily: 'Inter_400Regular', fontSize: 10, lineHeight: 15, marginTop: 9 },
  restoreRow: { flexDirection: 'row', gap: 8, marginTop: 12 },
  restoreButton: { flex: 1, minHeight: 40, borderRadius: 12, borderWidth: 1, paddingHorizontal: 9, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6 },
  restoreButtonText: { fontFamily: 'Inter_600SemiBold', fontSize: 10 },
  shareButton: { minHeight: 52, borderRadius: 16, paddingHorizontal: 15, flexDirection: 'row', alignItems: 'center', gap: 9 },
  shareText: { flex: 1, fontFamily: 'Inter_700Bold', fontSize: 13 },
});
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Feather } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { useEffect, useState } from 'react';
import {
  Image,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';
import { getDefaultOrderDraft, readOrderDraft, writeOrderDraft } from '@/lib/orderDraftStorage';

const colorNames = [
  'Hitam', 'Putih', 'Moka', 'Cream', 'Turkis', 'Army', 'Orange',
  'Biru Muda', 'Biru Tua', 'Hijau Muda', 'Hijau Tua', 'Kuning',
  'Merah', 'Pink', 'Lilac', 'Maroon', 'Navy', 'Abu Misty',
  'Coklat Tua', 'Fuchsia', 'Ungu Tua', 'Hijau Botol', 'Salem',
  'Steel Blue', 'Abu Tua', 'Sage Blue', 'Toska', 'Mustard',
];

export default function CatalogScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const [selectedColor, setSelectedColor] = useState('Hitam');

  useEffect(() => {
    readOrderDraft(AsyncStorage, getDefaultOrderDraft())
      .then((draft) => {
        if (colorNames.includes(draft.shirtColor)) {
          setSelectedColor(draft.shirtColor);
        }
      })
      .catch((error) => {
        console.warn('Tidak dapat memuat warna katalog terakhir.', error);
      });
  }, []);

  const selectColor = (color: string) => {
    setSelectedColor(color);
    void readOrderDraft(AsyncStorage, getDefaultOrderDraft())
      .then((draft) => writeOrderDraft(AsyncStorage, { ...draft, shirtColor: color }))
      .catch((error) => {
        console.warn('Tidak dapat menyimpan warna katalog.', error);
      });
  };

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      <ScrollView
        contentContainerStyle={[
          styles.content,
          { paddingTop: insets.top + 18, paddingBottom: insets.bottom + 96 },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.header}>
          <View>
            <Text style={[styles.eyebrow, { color: colors.burgundy }]}>KATALOG WARNA</Text>
            <Text style={[styles.title, { color: colors.ink }]}>Pilih kaos yang cocok</Text>
            <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
              Semua pilihan warna dalam satu tampilan.
            </Text>
          </View>
          <View style={[styles.headerIcon, { backgroundColor: colors.secondary }]}>
            <Feather name="droplet" size={20} color={colors.burgundy} />
          </View>
        </View>

        <View style={[styles.imageCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Image source={require('../../assets/images/color-catalog.png')} style={styles.catalogImage} resizeMode="contain" />
          <Text style={[styles.imageCaption, { color: colors.mutedForeground }]}>
            Koleksi kaos pendek bahan cotton combed 24s untuk anak dan dewasa.
          </Text>
        </View>

        <View style={[styles.selectionCard, { backgroundColor: colors.ink }]}>
          <Text style={[styles.selectionEyebrow, { color: colors.gold }]}>WARNA PILIHAN</Text>
          <View style={styles.selectionRow}>
            <View>
              <Text style={[styles.selectionLabel, { color: colors.sand }]}>Warna yang dipilih</Text>
              <Text style={[styles.selectionValue, { color: colors.cream }]}>{selectedColor}</Text>
              <Text style={[styles.selectionHint, { color: colors.sand }]}>Otomatis dibawa ke formulir pesanan</Text>
            </View>
            <View style={[styles.selectionDot, { backgroundColor: colors.gold }]} />
          </View>
        </View>

        <View style={styles.sectionHeader}>
          <View>
            <Text style={[styles.eyebrow, { color: colors.burgundy }]}>PILIHAN WARNA</Text>
            <Text style={[styles.sectionTitle, { color: colors.ink }]}>Tap warna untuk memilih</Text>
          </View>
          <Text style={[styles.count, { color: colors.mutedForeground }]}>{colorNames.length} warna</Text>
        </View>

        <View style={styles.colorGrid}>
          {colorNames.map((name) => {
            const isActive = selectedColor === name;
            return (
              <Pressable
                key={name}
                testID={`catalog-color-${name.toLowerCase().replaceAll(' ', '-')}`}
                onPress={() => selectColor(name)}
                style={({ pressed }) => [
                  styles.colorChip,
                  {
                    backgroundColor: isActive ? colors.gold : colors.card,
                    borderColor: isActive ? colors.gold : colors.border,
                    opacity: pressed ? 0.75 : 1,
                  },
                ]}
              >
                <View style={[styles.colorIndicator, { backgroundColor: isActive ? colors.burgundy : colors.secondary }]} />
                <Text style={[styles.colorText, { color: isActive ? colors.ink : colors.mutedForeground }]}>{name}</Text>
              </Pressable>
            );
          })}
        </View>

        <View style={[styles.positionCard, { backgroundColor: colors.secondary }]}>
          <View style={styles.positionIcon}>
            <Feather name="maximize" size={20} color={colors.burgundy} />
          </View>
          <View style={styles.positionCopy}>
            <Text style={[styles.positionEyebrow, { color: colors.burgundy }]}>POSISI DESAIN</Text>
            <Text style={[styles.positionTitle, { color: colors.ink }]}>Depan, belakang, atau keduanya</Text>
            <Text style={[styles.positionText, { color: colors.mutedForeground }]}>
              Pilih posisi desain sesuai kebutuhan pesanan custom Anda.
            </Text>
          </View>
        </View>

        <Pressable
          testID="catalog-order-button"
          onPress={() => router.push('/')}
          style={({ pressed }) => [
            styles.orderButton,
            { backgroundColor: colors.burgundy, opacity: pressed ? 0.82 : 1 },
          ]}
        >
          <Feather name="arrow-left" size={18} color={colors.gold} />
          <Text style={[styles.orderButtonText, { color: colors.cream }]}>Lanjut pilih ukuran dan pesan</Text>
          <Feather name="arrow-up-right" size={18} color={colors.gold} />
        </Pressable>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  content: { paddingHorizontal: 20, gap: 18 },
  header: { flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between' },
  eyebrow: { fontFamily: 'Inter_700Bold', fontSize: 10, letterSpacing: 1.45, marginBottom: 5 },
  title: { fontFamily: 'Inter_700Bold', fontSize: 27, letterSpacing: -1 },
  subtitle: { fontFamily: 'Inter_400Regular', fontSize: 12, lineHeight: 18, marginTop: 5 },
  headerIcon: { width: 44, height: 44, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },
  imageCard: { borderRadius: 24, borderWidth: 1, padding: 8, overflow: 'hidden' },
  catalogImage: { width: '100%', height: 340 },
  imageCaption: { fontFamily: 'Inter_400Regular', fontSize: 11, lineHeight: 16, paddingHorizontal: 8, paddingBottom: 7, textAlign: 'center' },
  selectionCard: { borderRadius: 20, padding: 17 },
  selectionEyebrow: { fontFamily: 'Inter_700Bold', fontSize: 9, letterSpacing: 1.3 },
  selectionRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 12 },
  selectionLabel: { fontFamily: 'Inter_400Regular', fontSize: 11 },
  selectionValue: { fontFamily: 'Inter_700Bold', fontSize: 21, marginTop: 3 },
  selectionHint: { fontFamily: 'Inter_400Regular', fontSize: 9, marginTop: 4 },
  selectionDot: { width: 28, height: 28, borderRadius: 14 },
  sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-end' },
  sectionTitle: { fontFamily: 'Inter_700Bold', fontSize: 19, letterSpacing: -0.5 },
  count: { fontFamily: 'Inter_500Medium', fontSize: 11, marginBottom: 3 },
  colorGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  colorChip: { width: '31.8%', minHeight: 45, borderRadius: 13, borderWidth: 1, paddingHorizontal: 8, flexDirection: 'row', alignItems: 'center', gap: 6 },
  colorIndicator: { width: 12, height: 12, borderRadius: 6 },
  colorText: { flex: 1, fontFamily: 'Inter_600SemiBold', fontSize: 10 },
  positionCard: { borderRadius: 20, padding: 14, flexDirection: 'row', alignItems: 'center', gap: 11 },
  positionIcon: { width: 42, height: 42, borderRadius: 14, backgroundColor: '#F8F3ED', alignItems: 'center', justifyContent: 'center' },
  positionCopy: { flex: 1 },
  positionEyebrow: { fontFamily: 'Inter_700Bold', fontSize: 9, letterSpacing: 1.1 },
  positionTitle: { fontFamily: 'Inter_700Bold', fontSize: 15, marginTop: 3 },
  positionText: { fontFamily: 'Inter_400Regular', fontSize: 10, lineHeight: 15, marginTop: 3 },
  orderButton: { minHeight: 55, borderRadius: 18, paddingHorizontal: 15, flexDirection: 'row', alignItems: 'center', gap: 9 },
  orderButtonText: { flex: 1, fontFamily: 'Inter_700Bold', fontSize: 13 },
});
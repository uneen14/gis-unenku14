import { Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { useFocusEffect } from 'expo-router';
import {
  Alert,
  Image,
  Linking,
  Modal,
  Platform,
  Pressable,
  Share,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import {
  DEFAULT_WHATSAPP_BUSINESS_NUMBER,
  formatWhatsAppNumber,
  isValidWhatsAppNumber,
  normalizeWhatsAppNumber,
  WHATSAPP_BUSINESS_NUMBER_STORAGE_KEY,
} from '@/constants/whatsapp';
import {
  readTemplateDrafts,
  writeTemplateDrafts,
} from '@/lib/templateDraftStorage';
import {
  getDefaultOrderDraft,
  type OrderDraft,
  readOrderDraft,
  writeOrderDraft,
} from '@/lib/orderDraftStorage';

type CatalogItem = {
  name: string;
  prices: number[];
};

type CatalogCategory = {
  id: string;
  name: string;
  eyebrow: string;
  description: string;
  sizes: string[];
  items: CatalogItem[];
};

const catalog: CatalogCategory[] = [
  {
    id: 'anak',
    name: 'Kaos Anak',
    eyebrow: 'Koleksi kecil',
    description: 'Nyaman untuk hari aktif, dari bermain sampai acara keluarga.',
    sizes: ['0–12 bln', '1–3 thn', '4–6 thn', '7–9 thn', '10–12 thn'],
    items: [
      { name: 'Logo kecil di dada', prices: [54905, 60663, 63957, 66183, 68409] },
      { name: 'Gambar sedang (A4+)', prices: [68096, 71390, 74686, 76913, 79140] },
      { name: 'Logo + Logo', prices: [62732, 66026, 69322, 70720, 73774] },
    ],
  },
  {
    id: 'dewasa',
    name: 'Kaos Dewasa',
    eyebrow: 'Koleksi utama',
    description: 'Potongan nyaman untuk kebutuhan personal, komunitas, dan usaha.',
    sizes: ['S', 'M', 'L', 'XL', 'XXL', '3XL / 4XL'],
    items: [
      { name: 'Logo kecil di dada', prices: [86042, 86042, 89516, 89516, 92899, 92899] },
      { name: 'Gambar sedang (A4+)', prices: [96772, 97573, 100244, 100244, 103628, 103628] },
      { name: 'Gambar besar (A3)', prices: [102136, 102136, 105608, 105608, 108993, 108993] },
      { name: 'Logo + A4+', prices: [91720, 99779, 99900, 99900, 108993, 108993] },
    ],
  },
];

const formatRupiah = (value: number) =>
  `Rp${value.toLocaleString('id-ID')}`;

type QuickReply = {
  id: string;
  shortcut: string;
  title: string;
  message: string;
};

const quickReplies: QuickReply[] = [
  {
    id: 'salam',
    shortcut: '/salam',
    title: 'Menyambut pelanggan',
    message: 'Halo! Terima kasih sudah menghubungi D’Zahwa Collections 👕 Kami melayani kaos custom anak dan dewasa dengan foto, tulisan, atau logo. Ada desain yang ingin dibuat?',
  },
  {
    id: 'format',
    shortcut: '/format',
    title: 'Meminta detail pesanan',
    message: 'Agar kami bisa bantu cek pesanan, mohon kirim:\n• Foto/logo/tulisan untuk desain\n• Warna kaos\n• Ukuran dan jumlah masing-masing\n• Posisi desain: depan, belakang, atau keduanya\n• Tanggal dibutuhkan\n• Kota tujuan pengiriman',
  },
  {
    id: 'harga',
    shortcut: '/harga',
    title: 'Menjawab pertanyaan harga',
    message: 'Harga kaos custom bergantung pada ukuran, jumlah, dan penempatan desain. Kirim ukuran serta desain yang diinginkan, ya. Setelah itu kami buatkan rincian harga sebelum pesanan diproses.',
  },
  {
    id: 'desain',
    shortcut: '/desain',
    title: 'Memastikan tulisan dan tata letak',
    message: 'Mohon periksa kembali contoh desain yang kami kirim, terutama ejaan nama/tulisan, warna, dan posisi gambar. Jika semuanya sudah sesuai, balas DESAIN SETUJU.',
  },
  {
    id: 'total',
    shortcut: '/total',
    title: 'Mengirim rincian pesanan',
    message: 'Rincian pesanan Anda:\nDesain: [isi]\nWarna: [isi]\nUkuran dan jumlah: [isi]\nPosisi sablon: [isi]\nHarga kaos: Rp[isi]\nOngkir: Rp[isi]\nTotal: Rp[isi]\nPerkiraan selesai: [isi]\n\nMohon periksa rinciannya. Jika sudah sesuai, balas PESANAN SETUJU.',
  },
  {
    id: 'proses',
    shortcut: '/proses',
    title: 'Memberi kabar pesanan',
    message: 'Halo! Pesanan D’Zahwa Collections Anda saat ini sedang [tahap pesanan]. Kami akan mengabari Anda lagi saat [tahap berikutnya]. Terima kasih sudah menunggu 🙏',
  },
  {
    id: 'kirim',
    shortcut: '/kirim',
    title: 'Mengirim resi',
    message: 'Pesanan Anda sudah dikirim 📦\nKurir: [nama kurir]\nNomor resi: [nomor resi]\n\nTerima kasih sudah memesan di D’Zahwa Collections. Semoga kaosnya cocok dan nyaman dipakai!',
  },
  {
    id: 'terimakasih',
    shortcut: '/terimakasih',
    title: 'Setelah pesanan selesai',
    message: 'Terima kasih sudah memesan kaos custom di D’Zahwa Collections 👕💛\n\nSemoga kaosnya cocok dan nyaman dipakai. Kalau sudah diterima, kami senang sekali mendengar pendapat Anda. Sampai bertemu di pesanan berikutnya!',
  },
];

const DESIGN_POSITIONS = ['Depan', 'Belakang', 'Keduanya'];

const SHIRT_COLORS = [
  'Hitam', 'Putih', 'Moka', 'Cream', 'Turkis', 'Army', 'Orange',
  'Biru Muda', 'Biru Tua', 'Hijau Muda', 'Hijau Tua', 'Kuning',
  'Merah', 'Pink', 'Lilac', 'Maroon', 'Navy', 'Abu Misty',
  'Coklat Tua', 'Fuchsia', 'Ungu Tua', 'Hijau Botol', 'Salem',
  'Steel Blue', 'Abu Tua', 'Sage Blue', 'Toska', 'Mustard',
];

const getDefaultTemplateDrafts = () =>
  Object.fromEntries(quickReplies.map((reply) => [reply.id, reply.message]));

export default function TabOneScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [activeCategoryId, setActiveCategoryId] = useState('dewasa');
  const [activeSizeIndex, setActiveSizeIndex] = useState(1);
  const [selectedItemIndex, setSelectedItemIndex] = useState(0);
  const [catalogVisible, setCatalogVisible] = useState(false);
  const [guideVisible, setGuideVisible] = useState(false);
  const [templatesVisible, setTemplatesVisible] = useState(false);
  const [selectedTemplateId, setSelectedTemplateId] = useState('salam');
  const [templateDrafts, setTemplateDrafts] = useState<Record<string, string>>(
    getDefaultTemplateDrafts,
  );
  const [templateDraftsLoaded, setTemplateDraftsLoaded] = useState(false);
  const [templateDraftsLoadFailed, setTemplateDraftsLoadFailed] = useState(false);
  const [templateStorageError, setTemplateStorageError] = useState<string | null>(null);
  const [whatsappBusinessNumber, setWhatsappBusinessNumber] = useState(
    DEFAULT_WHATSAPP_BUSINESS_NUMBER,
  );
  const [designDescription, setDesignDescription] = useState('');
  const [designPosition, setDesignPosition] = useState('Depan');
  const [shirtColor, setShirtColor] = useState('Hitam');
  const [sizeQuantities, setSizeQuantities] = useState<Record<string, string>>({
    S: '1',
  });
  const [neededDate, setNeededDate] = useState('');
  const [destinationCity, setDestinationCity] = useState('');
  const [orderDraftLoaded, setOrderDraftLoaded] = useState(false);
  const [orderDraftStorageError, setOrderDraftStorageError] = useState<string | null>(null);

  useEffect(() => {
    let isMounted = true;

    const loadTemplateDrafts = async () => {
      try {
        const drafts = await readTemplateDrafts(AsyncStorage, getDefaultTemplateDrafts());
        if (!isMounted) {
          return;
        }

        setTemplateDrafts(drafts);
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        console.warn(message);
        if (isMounted) {
          setTemplateDraftsLoadFailed(true);
          setTemplateStorageError(message);
        }
      } finally {
        if (isMounted) {
          setTemplateDraftsLoaded(true);
        }
      }
    };

    void loadTemplateDrafts();

    return () => {
      isMounted = false;
    };
  }, []);

  useEffect(() => {
    if (!templateDraftsLoaded || templateDraftsLoadFailed) {
      return;
    }

    void writeTemplateDrafts(AsyncStorage, templateDrafts).catch((error: unknown) => {
      const message = error instanceof Error ? error.message : String(error);
      console.warn(message);
      setTemplateStorageError(message);
    });
  }, [templateDrafts, templateDraftsLoaded, templateDraftsLoadFailed]);

  useEffect(() => {
    let isMounted = true;

    const loadOrderDraft = async () => {
      try {
        const draft = await readOrderDraft(AsyncStorage, getDefaultOrderDraft());
        if (!isMounted) {
          return;
        }

        const category = catalog.find((item) => item.id === draft.activeCategoryId) ?? catalog[1];
        const safeSizeIndex = Math.min(
          Math.max(draft.activeSizeIndex, 0),
          category.sizes.length - 1,
        );
        const safeItemIndex = Math.min(
          Math.max(draft.selectedItemIndex, 0),
          category.items.length - 1,
        );

        setActiveCategoryId(category.id);
        setActiveSizeIndex(safeSizeIndex);
        setSelectedItemIndex(safeItemIndex);
        setDesignDescription(draft.designDescription);
        setDesignPosition(
          DESIGN_POSITIONS.includes(draft.designPosition)
            ? draft.designPosition
            : 'Depan',
        );
        setShirtColor(SHIRT_COLORS.includes(draft.shirtColor) ? draft.shirtColor : 'Hitam');
        setSizeQuantities(draft.sizeQuantities);
        setNeededDate(draft.neededDate);
        setDestinationCity(draft.destinationCity);
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        console.warn(message);
        if (isMounted) {
          setOrderDraftStorageError(message);
        }
      } finally {
        if (isMounted) {
          setOrderDraftLoaded(true);
        }
      }
    };

    void loadOrderDraft();

    return () => {
      isMounted = false;
    };
  }, []);

  useEffect(() => {
    if (!orderDraftLoaded) {
      return;
    }

    const draft: OrderDraft = {
      activeCategoryId,
      activeSizeIndex,
      selectedItemIndex,
      designDescription,
      designPosition,
      shirtColor,
      sizeQuantities,
      neededDate,
      destinationCity,
    };

    void writeOrderDraft(AsyncStorage, draft)
      .then(() => setOrderDraftStorageError(null))
      .catch((error: unknown) => {
        const message = error instanceof Error ? error.message : String(error);
        console.warn(message);
        setOrderDraftStorageError(message);
      });
  }, [
    activeCategoryId,
    activeSizeIndex,
    selectedItemIndex,
    designDescription,
    designPosition,
    shirtColor,
    sizeQuantities,
    neededDate,
    destinationCity,
    orderDraftLoaded,
  ]);

  const syncOrderDraftColor = useCallback(async () => {
    try {
      const draft = await readOrderDraft(AsyncStorage, getDefaultOrderDraft());
      if (SHIRT_COLORS.includes(draft.shirtColor)) {
        setShirtColor(draft.shirtColor);
      }
    } catch (error) {
      console.warn('Tidak dapat menyinkronkan warna dari katalog.', error);
    }
  }, []);

  const loadWhatsAppBusinessNumber = useCallback(async () => {
    try {
      const storedNumber = await AsyncStorage.getItem(WHATSAPP_BUSINESS_NUMBER_STORAGE_KEY);
      if (storedNumber && isValidWhatsAppNumber(storedNumber)) {
        setWhatsappBusinessNumber(normalizeWhatsAppNumber(storedNumber));
      }
    } catch (error) {
      console.warn('Tidak dapat memuat nomor WhatsApp Business.', error);
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      void loadWhatsAppBusinessNumber();
      if (orderDraftLoaded) {
        void syncOrderDraftColor();
      }
    }, [loadWhatsAppBusinessNumber, orderDraftLoaded, syncOrderDraftColor]),
  );

  const activeCategory = useMemo(
    () => catalog.find((category) => category.id === activeCategoryId) ?? catalog[1],
    [activeCategoryId],
  );

  const selectedItem = activeCategory.items[selectedItemIndex] ?? activeCategory.items[0];

  const orderEstimate = useMemo(
    () =>
      activeCategory.sizes.reduce(
        (summary, size, index) => {
          const quantity = Number.parseInt(sizeQuantities[size] ?? '', 10);
          if (!Number.isInteger(quantity) || quantity <= 0) {
            return summary;
          }

          summary.totalQuantity += quantity;
          summary.subtotal += quantity * selectedItem.prices[index];
          return summary;
        },
        { totalQuantity: 0, subtotal: 0 },
      ),
    [activeCategory, selectedItem, sizeQuantities],
  );

  const selectCategory = (categoryId: string) => {
    Haptics.selectionAsync();
    setActiveCategoryId(categoryId);
    setActiveSizeIndex(categoryId === 'dewasa' ? 1 : 0);
    setSelectedItemIndex(0);
    const nextCategory = catalog.find((category) => category.id === categoryId);
    if (nextCategory) {
      setSizeQuantities((current) =>
        Object.fromEntries(
          nextCategory.sizes.map((size, index) => [
            size,
            current[size] ?? (index === 0 ? '1' : ''),
          ]),
        ),
      );
    }
  };

  const selectSize = (index: number) => {
    Haptics.selectionAsync();
    setActiveSizeIndex(index);
  };

  const openWhatsApp = async () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    const trimmedDesign = designDescription.trim();
    const trimmedDate = neededDate.trim();
    const trimmedCity = destinationCity.trim();
    const sizeDetails = activeCategory.sizes
      .map((size) => ({
        size,
        quantity: Number.parseInt(sizeQuantities[size] ?? '', 10),
      }))
      .filter(
        (item) =>
          Number.isInteger(item.quantity) && item.quantity > 0,
      );

    if (!trimmedDesign || !trimmedDate || !trimmedCity || sizeDetails.length === 0) {
      Alert.alert(
        'Lengkapi detail pesanan',
        'Isi desain/tulisan, jumlah minimal satu ukuran, tanggal dibutuhkan, dan kota tujuan sebelum membuka WhatsApp.',
      );
      return;
    }

    const sizeSummary = sizeDetails
      .map((item) => `${item.size}: ${item.quantity} pcs`)
      .join(', ');
    const message = [
      'Halo DZahwa Collections, saya ingin memesan kaos custom.',
      '',
      `• Koleksi: ${activeCategory.name}`,
      `• Jenis sablon: ${selectedItem.name}`,
      `• Desain/tulisan: ${trimmedDesign}`,
      `• Posisi desain: ${designPosition}`,
      `• Warna kaos: ${shirtColor}`,
      `• Ukuran dan jumlah: ${sizeSummary}`,
      `• Estimasi subtotal kaos: ${formatRupiah(orderEstimate.subtotal)}`,
      `• Dibutuhkan: ${trimmedDate}`,
      `• Kota tujuan: ${trimmedCity}`,
      '',
      'Catatan: subtotal di aplikasi adalah perkiraan awal dan belum termasuk ongkir atau penyesuaian desain.',
    ].join('\n');
    const url = `https://wa.me/${whatsappBusinessNumber}?text=${encodeURIComponent(message)}`;
    const canOpen = await Linking.canOpenURL(url);
    if (canOpen) {
      await Linking.openURL(url);
      return;
    }
    Alert.alert('WhatsApp belum tersedia', 'Silakan pasang WhatsApp atau hubungi admin melalui browser.');
  };

  const resetOrderDraft = () => {
    Alert.alert(
      'Kosongkan draft pesanan?',
      'Detail desain, warna, ukuran, jumlah, tanggal, dan kota tujuan akan dikembalikan ke awal.',
      [
        { text: 'Batal', style: 'cancel' },
        {
          text: 'Kosongkan',
          style: 'destructive',
          onPress: () => {
            const defaults = getDefaultOrderDraft();
            setActiveCategoryId(defaults.activeCategoryId);
            setActiveSizeIndex(defaults.activeSizeIndex);
            setSelectedItemIndex(defaults.selectedItemIndex);
            setDesignDescription(defaults.designDescription);
            setDesignPosition(defaults.designPosition);
            setShirtColor(defaults.shirtColor);
            setSizeQuantities(defaults.sizeQuantities);
            setNeededDate(defaults.neededDate);
            setDestinationCity(defaults.destinationCity);
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
          },
        },
      ],
    );
  };

  const openTemplateWhatsApp = async () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    const message = [
      'Halo D’Zahwa Collections, saya ingin konsultasi kaos custom.',
      '',
      'Desain/tulisan:',
      'Posisi desain (depan, belakang, atau keduanya):',
      'Warna kaos:',
      'Ukuran dan jumlah:',
      'Tanggal dibutuhkan:',
      'Kota tujuan:',
    ].join('\n');
    const url = `https://wa.me/${whatsappBusinessNumber}?text=${encodeURIComponent(message)}`;
    const canOpen = await Linking.canOpenURL(url);
    if (canOpen) {
      await Linking.openURL(url);
      return;
    }
    Alert.alert('WhatsApp belum tersedia', 'Silakan pasang WhatsApp atau hubungi admin melalui browser.');
  };

  const selectedTemplate = quickReplies.find((reply) => reply.id === selectedTemplateId) ?? quickReplies[0];

  const getSelectedTemplateMessage = () => templateDrafts[selectedTemplate.id]?.trim() ?? '';

  const shareTemplate = async (message = getSelectedTemplateMessage()) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    if (!message) {
      Alert.alert('Template masih kosong', 'Tulis isi template sebelum membagikannya.');
      return;
    }

    try {
      await Share.share({ message });
    } catch (error) {
      console.warn('Tidak dapat membuka menu berbagi template.', error);
      Alert.alert('Template belum terbagi', 'Coba lagi atau salin isi template secara manual.');
    }
  };

  const restoreSelectedTemplate = () => {
    Alert.alert(
      'Pulihkan pintasan ini?',
      `Isi ${selectedTemplate.shortcut} akan dikembalikan ke teks bawaan.`,
      [
        { text: 'Batal', style: 'cancel' },
        {
          text: 'Pulihkan',
          onPress: () => {
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
            setTemplateDrafts((drafts) => ({
              ...drafts,
              [selectedTemplate.id]: selectedTemplate.message,
            }));
          },
        },
      ],
    );
  };

  const restoreAllTemplates = () => {
    Alert.alert(
      'Pulihkan semua template?',
      'Semua perubahan lokal pada 8 template akan dihapus dan diganti teks bawaan.',
      [
        { text: 'Batal', style: 'cancel' },
        {
          text: 'Pulihkan semua',
          style: 'destructive',
          onPress: () => {
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
            setTemplateDrafts(getDefaultTemplateDrafts());
          },
        },
      ],
    );
  };

  const sendTemplateToWhatsApp = async () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    const message = getSelectedTemplateMessage();
    if (!message) {
      Alert.alert('Template masih kosong', 'Tulis isi template sebelum mengirimkannya.');
      return;
    }

    const url = `whatsapp://send?phone=${whatsappBusinessNumber}&text=${encodeURIComponent(message)}`;

    try {
      if (await Linking.canOpenURL(url)) {
        await Linking.openURL(url);
        return;
      }
    } catch (error) {
      console.warn('WhatsApp tidak dapat dibuka langsung.', error);
    }

    await shareTemplate(message);
  };

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      <KeyboardAwareScrollViewCompat
        contentContainerStyle={[
          styles.content,
          {
            paddingTop: insets.top + 16,
            paddingBottom: insets.bottom + 94,
          },
        ]}
        showsVerticalScrollIndicator={false}
        bottomOffset={24}
        keyboardDismissMode="interactive"
      >
        <View style={styles.topBar}>
          <View style={styles.brandLockup}>
            <Image source={require('../../assets/images/brand-logo.png')} style={styles.brandLogo} />
            <View>
              <Text style={[styles.brandName, { color: colors.ink }]}>DZahwa</Text>
              <Text style={[styles.brandCaption, { color: colors.mutedForeground }]}>COLLECTIONS</Text>
            </View>
          </View>
          <View style={styles.topActions}>
            <Pressable
              accessibilityLabel="Buka cara pesan"
              testID="guide-button"
              onPress={() => setGuideVisible(true)}
              style={({ pressed }) => [
                styles.guidePill,
                { backgroundColor: colors.secondary, opacity: pressed ? 0.72 : 1 },
              ]}
            >
              <Feather name="help-circle" size={16} color={colors.burgundy} />
              <Text style={[styles.guidePillText, { color: colors.burgundy }]}>Cara pesan</Text>
            </Pressable>
            <Pressable
              accessibilityLabel="Buka katalog visual"
              testID="catalog-button"
              onPress={() => setCatalogVisible(true)}
              style={({ pressed }) => [
                styles.iconButton,
                { backgroundColor: colors.card, borderColor: colors.border, opacity: pressed ? 0.72 : 1 },
              ]}
            >
              <Feather name="maximize-2" size={19} color={colors.ink} />
            </Pressable>
          </View>
        </View>

        <View style={[styles.welcomeCard, { backgroundColor: colors.ink }]}>
          <View style={styles.welcomeCopy}>
            <Text style={[styles.welcomeEyebrow, { color: colors.gold }]}>CUSTOM PRINT STUDIO</Text>
            <Text style={styles.welcomeTitle}>Bikin kaos yang terasa seperti milikmu.</Text>
            <Text style={[styles.welcomeDescription, { color: colors.sand }]}>
              Pilih koleksi, tentukan ukuran, lalu konsultasikan desain langsung dengan admin.
            </Text>
          </View>
          <View style={[styles.welcomeMark, { backgroundColor: colors.burgundy }]}>
            <Feather name="arrow-up-right" size={26} color={colors.cream} />
          </View>
        </View>

        <View style={styles.sectionHeading}>
          <View>
            <Text style={[styles.sectionEyebrow, { color: colors.burgundy }]}>PILIH KOLEKSI</Text>
            <Text style={[styles.sectionTitle, { color: colors.ink }]}>Mulai dari kebutuhanmu</Text>
          </View>
          <Text style={[styles.sectionCount, { color: colors.mutedForeground }]}>02 pilihan</Text>
        </View>

        <View style={styles.categoryRow}>
          {catalog.map((category) => {
            const isActive = activeCategory.id === category.id;
            return (
              <Pressable
                key={category.id}
                testID={`category-${category.id}`}
                onPress={() => selectCategory(category.id)}
                style={({ pressed }) => [
                  styles.categoryCard,
                  {
                    backgroundColor: isActive ? colors.burgundy : colors.card,
                    borderColor: isActive ? colors.burgundy : colors.border,
                    opacity: pressed ? 0.8 : 1,
                  },
                ]}
              >
                <View style={[styles.categoryIcon, { backgroundColor: isActive ? colors.burgundyDark : colors.secondary }]}>
                  <Feather name={category.id === 'dewasa' ? 'user' : 'smile'} size={20} color={isActive ? colors.cream : colors.burgundy} />
                </View>
                <Text style={[styles.categoryEyebrow, { color: isActive ? colors.sand : colors.mutedForeground }]}>{category.eyebrow}</Text>
                <Text style={[styles.categoryName, { color: isActive ? colors.cream : colors.ink }]}>{category.name}</Text>
                <View style={styles.categoryArrow}>
                  <Feather name="arrow-up-right" size={16} color={isActive ? colors.gold : colors.burgundy} />
                </View>
              </Pressable>
            );
          })}
        </View>

        <View style={styles.detailHeader}>
          <View style={styles.detailTitleWrap}>
            <Text style={[styles.detailEyebrow, { color: colors.burgundy }]}>{activeCategory.eyebrow.toUpperCase()}</Text>
            <Text style={[styles.detailTitle, { color: colors.ink }]}>{activeCategory.name}</Text>
            <Text style={[styles.detailDescription, { color: colors.mutedForeground }]}>{activeCategory.description}</Text>
          </View>
          <View style={[styles.priceNote, { backgroundColor: colors.secondary }]}>
            <Feather name="tag" size={16} color={colors.burgundy} />
            <Text style={[styles.priceNoteText, { color: colors.secondaryForeground }]}>Harga satuan</Text>
          </View>
        </View>

        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.sizeRow}>
          {activeCategory.sizes.map((size, index) => {
            const isActive = index === activeSizeIndex;
            return (
              <Pressable
                key={size}
                testID={`size-${index}`}
                onPress={() => selectSize(index)}
                style={({ pressed }) => [
                  styles.sizeChip,
                  {
                    backgroundColor: isActive ? colors.gold : colors.card,
                    borderColor: isActive ? colors.gold : colors.border,
                    opacity: pressed ? 0.72 : 1,
                  },
                ]}
              >
                <Text style={[styles.sizeText, { color: isActive ? colors.ink : colors.mutedForeground }]}>{size}</Text>
              </Pressable>
            );
          })}
        </ScrollView>

        <View style={styles.itemsList}>
          {activeCategory.items.map((item, index) => {
            const isSelected = index === selectedItemIndex;
            return (
              <Pressable
                key={item.name}
                testID={`print-item-${index}`}
                onPress={() => {
                  Haptics.selectionAsync();
                  setSelectedItemIndex(index);
                }}
                style={({ pressed }) => [
                  styles.itemRow,
                  {
                    backgroundColor: isSelected ? colors.secondary : colors.card,
                    borderColor: isSelected ? colors.gold : colors.border,
                    opacity: pressed ? 0.78 : 1,
                  },
                ]}
              >
                <View style={[styles.itemNumber, { backgroundColor: isSelected ? colors.burgundy : colors.secondary }]}>
                  <Text style={[styles.itemNumberText, { color: isSelected ? colors.cream : colors.burgundy }]}>0{index + 1}</Text>
                </View>
                <View style={styles.itemCopy}>
                  <Text style={[styles.itemName, { color: colors.ink }]}>{item.name}</Text>
                  <Text style={[styles.itemMeta, { color: colors.mutedForeground }]}>
                    {isSelected ? 'Dipilih untuk pesanan' : 'Tap untuk memilih'} • {activeCategory.sizes[activeSizeIndex]}
                  </Text>
                </View>
                <View style={styles.itemPriceWrap}>
                  {isSelected ? <Feather name="check-circle" size={15} color={colors.burgundy} /> : null}
                  <Text style={[styles.itemPrice, { color: colors.burgundy }]}>{formatRupiah(item.prices[activeSizeIndex])}</Text>
                </View>
              </Pressable>
            );
          })}
        </View>

        <View style={[styles.orderForm, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={styles.formHeading}>
            <View style={styles.formHeadingCopy}>
              <Text style={[styles.sectionEyebrow, { color: colors.burgundy }]}>DETAIL PESANAN</Text>
              <Text style={[styles.formTitle, { color: colors.ink }]}>Biar admin langsung paham</Text>
              <Text style={[styles.formDescription, { color: colors.mutedForeground }]}>
                Isi singkatannya, lalu lanjutkan ke WhatsApp tanpa mengetik ulang.
              </Text>
              <View style={styles.draftStatusRow}>
                <Feather
                  name={orderDraftStorageError ? 'alert-circle' : 'save'}
                  size={13}
                  color={orderDraftStorageError ? colors.burgundy : colors.sage}
                />
                <Text
                  style={[
                    styles.draftStatusText,
                    { color: orderDraftStorageError ? colors.burgundy : colors.sage },
                  ]}
                >
                  {orderDraftStorageError ? 'Draft belum tersimpan' : 'Draft tersimpan otomatis'}
                </Text>
              </View>
            </View>
            <View style={[styles.formNumber, { backgroundColor: colors.secondary }]}>
              <Text style={[styles.formNumberText, { color: colors.burgundy }]}>01</Text>
            </View>
          </View>

          <View style={styles.fieldGroup}>
            <Text style={[styles.fieldLabel, { color: colors.ink }]}>Desain atau tulisan</Text>
            <TextInput
              testID="design-input"
              value={designDescription}
              onChangeText={setDesignDescription}
              placeholder="Contoh: logo komunitas + tulisan di bawahnya"
              placeholderTextColor={colors.mutedForeground}
              multiline
              textAlignVertical="top"
              style={[styles.textInput, styles.designInput, { backgroundColor: colors.background, borderColor: colors.input, color: colors.ink }]}
            />
          </View>

          <View style={styles.fieldGroup}>
            <Text style={[styles.fieldLabel, { color: colors.ink }]}>Posisi desain</Text>
            <View style={styles.optionRow}>
              {DESIGN_POSITIONS.map((position) => {
                const isActive = designPosition === position;
                return (
                  <Pressable
                    key={position}
                    testID={`position-${position.toLowerCase()}`}
                    onPress={() => {
                      Haptics.selectionAsync();
                      setDesignPosition(position);
                    }}
                    style={({ pressed }) => [
                      styles.optionChip,
                      {
                        backgroundColor: isActive ? colors.burgundy : colors.background,
                        borderColor: isActive ? colors.burgundy : colors.input,
                        opacity: pressed ? 0.75 : 1,
                      },
                    ]}
                  >
                    <Text style={[styles.optionText, { color: isActive ? colors.cream : colors.mutedForeground }]}>{position}</Text>
                  </Pressable>
                );
              })}
            </View>
          </View>

          <View style={styles.fieldGroup}>
            <Text style={[styles.fieldLabel, { color: colors.ink }]}>Warna kaos</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.colorOptionRow}>
              {SHIRT_COLORS.map((color) => {
                const isActive = shirtColor === color;
                return (
                  <Pressable
                    key={color}
                    testID={`color-${color.toLowerCase()}`}
                    onPress={() => {
                      Haptics.selectionAsync();
                      setShirtColor(color);
                    }}
                    style={({ pressed }) => [
                      styles.optionChip,
                      {
                        backgroundColor: isActive ? colors.gold : colors.background,
                        borderColor: isActive ? colors.gold : colors.input,
                        opacity: pressed ? 0.75 : 1,
                      },
                    ]}
                  >
                    <Text style={[styles.optionText, { color: isActive ? colors.ink : colors.mutedForeground }]}>{color}</Text>
                  </Pressable>
                );
              })}
            </ScrollView>
            <Text style={[styles.fieldHint, { color: colors.mutedForeground }]}>Pilihan warna mengikuti katalog koleksi terbaru.</Text>
          </View>

          <View style={styles.fieldGroup}>
            <Text style={[styles.fieldLabel, { color: colors.ink }]}>Jenis sablon yang dipilih</Text>
            <View style={[styles.selectedPrintCard, { backgroundColor: colors.background, borderColor: colors.input }]}>
              <View style={[styles.selectedPrintIcon, { backgroundColor: colors.secondary }]}>
                <Feather name="check" size={16} color={colors.burgundy} />
              </View>
              <View style={styles.selectedPrintCopy}>
                <Text style={[styles.selectedPrintName, { color: colors.ink }]}>{selectedItem.name}</Text>
                <Text style={[styles.fieldHint, { color: colors.mutedForeground }]}>
                  Harga otomatis menyesuaikan ukuran dan jumlah di bawah.
                </Text>
              </View>
            </View>
          </View>

          <View style={styles.fieldGroup}>
            <Text style={[styles.fieldLabel, { color: colors.ink }]}>Ukuran dan jumlah</Text>
            <Text style={[styles.fieldHint, { color: colors.mutedForeground }]}>
              Isi jumlah untuk setiap ukuran yang dibutuhkan. Kosongkan ukuran yang tidak dipesan.
            </Text>
            <View style={styles.sizeQuantityList}>
              {activeCategory.sizes.map((size, index) => (
                <View
                  key={size}
                  style={[
                    styles.sizeQuantityRow,
                    { backgroundColor: colors.background, borderColor: colors.input },
                  ]}
                >
                  <View style={styles.sizeQuantityCopy}>
                    <Text style={[styles.sizeQuantitySize, { color: colors.ink }]}>{size}</Text>
                    <Text style={[styles.sizeQuantityPrice, { color: colors.mutedForeground }]}>
                      {formatRupiah(selectedItem.prices[index])} / pcs
                    </Text>
                  </View>
                  <TextInput
                    testID={`quantity-${size.toLowerCase().replaceAll(' ', '-')}`}
                    value={sizeQuantities[size] ?? ''}
                    onChangeText={(value) =>
                      setSizeQuantities((current) => ({
                        ...current,
                        [size]: value.replace(/[^0-9]/g, ''),
                      }))
                    }
                    placeholder="0"
                    placeholderTextColor={colors.mutedForeground}
                    keyboardType="number-pad"
                    style={[
                      styles.sizeQuantityInput,
                      { backgroundColor: colors.card, borderColor: colors.input, color: colors.ink },
                    ]}
                  />
                </View>
              ))}
            </View>
          </View>

          <View style={[styles.estimateCard, { backgroundColor: colors.ink }]}>
            <View style={styles.estimateTopRow}>
              <View>
                <Text style={[styles.estimateEyebrow, { color: colors.gold }]}>ESTIMASI PESANAN</Text>
                <Text style={[styles.estimateQuantity, { color: colors.sand }]}>
                  {orderEstimate.totalQuantity} pcs • {selectedItem.name}
                </Text>
              </View>
              <Feather name="shopping-bag" size={20} color={colors.gold} />
            </View>
            <Text style={[styles.estimateTotal, { color: colors.cream }]}>
              {formatRupiah(orderEstimate.subtotal)}
            </Text>
            <Text style={[styles.estimateNote, { color: colors.sand }]}>
              Perkiraan subtotal kaos. Ongkir dan penyesuaian desain dikonfirmasi admin sebelum diproses.
            </Text>
          </View>

          <View style={styles.fieldRow}>
            <View style={[styles.fieldGroup, styles.halfField]}>
              <Text style={[styles.fieldLabel, { color: colors.ink }]}>Tanggal dibutuhkan</Text>
              <TextInput
                testID="needed-date-input"
                value={neededDate}
                onChangeText={setNeededDate}
                placeholder="Contoh: 12 Okt 2026"
                placeholderTextColor={colors.mutedForeground}
                style={[styles.textInput, styles.compactInput, { backgroundColor: colors.background, borderColor: colors.input, color: colors.ink }]}
              />
            </View>
            <View style={[styles.fieldGroup, styles.halfField]}>
              <Text style={[styles.fieldLabel, { color: colors.ink }]}>Kota tujuan</Text>
              <TextInput
                testID="destination-city-input"
                value={destinationCity}
                onChangeText={setDestinationCity}
                placeholder="Contoh: Bandung"
                placeholderTextColor={colors.mutedForeground}
                style={[styles.textInput, styles.compactInput, { backgroundColor: colors.background, borderColor: colors.input, color: colors.ink }]}
              />
            </View>
          </View>

          <Pressable
            testID="reset-order-draft"
            onPress={resetOrderDraft}
            style={({ pressed }) => [
              styles.resetDraftButton,
              { borderColor: colors.border, backgroundColor: colors.background, opacity: pressed ? 0.72 : 1 },
            ]}
          >
            <Feather name="rotate-ccw" size={15} color={colors.burgundy} />
            <Text style={[styles.resetDraftText, { color: colors.burgundy }]}>Kosongkan draft pesanan</Text>
          </Pressable>
        </View>

        <Pressable
          testID="guide-card"
          onPress={() => setGuideVisible(true)}
          style={({ pressed }) => [
            styles.guideCard,
            { backgroundColor: colors.secondary, opacity: pressed ? 0.8 : 1 },
          ]}
        >
          <View style={[styles.guideIcon, { backgroundColor: colors.cream }]}>
            <Feather name="list" size={19} color={colors.burgundy} />
          </View>
          <View style={styles.guideCopy}>
            <Text style={[styles.guideEyebrow, { color: colors.burgundy }]}>PESAN KAOS CUSTOM</Text>
            <Text style={[styles.guideTitle, { color: colors.ink }]}>Belum tahu mulai dari mana?</Text>
            <Text style={[styles.guideDescription, { color: colors.mutedForeground }]}>Lihat langkah pemesanan yang perlu disiapkan.</Text>
          </View>
          <Feather name="arrow-up-right" size={20} color={colors.burgundy} />
        </Pressable>

        <Pressable
          testID="templates-card"
          onPress={() => setTemplatesVisible(true)}
          style={({ pressed }) => [
            styles.adminCard,
            { backgroundColor: colors.card, borderColor: colors.border, opacity: pressed ? 0.8 : 1 },
          ]}
        >
          <View style={[styles.adminIcon, { backgroundColor: colors.ink }]}>
            <Feather name="message-square" size={18} color={colors.gold} />
          </View>
          <View style={styles.guideCopy}>
            <Text style={[styles.guideEyebrow, { color: colors.burgundy }]}>UNTUK ADMIN</Text>
            <Text style={[styles.guideTitle, { color: colors.ink }]}>Balasan cepat WhatsApp</Text>
            <Text style={[styles.guideDescription, { color: colors.mutedForeground }]}>8 template siap edit dan dibagikan.</Text>
          </View>
          <Feather name="arrow-up-right" size={20} color={colors.burgundy} />
        </Pressable>

        <Pressable
          testID="whatsapp-button"
          onPress={openWhatsApp}
          style={({ pressed }) => [
            styles.whatsappButton,
            { backgroundColor: colors.burgundy, opacity: pressed ? 0.82 : 1 },
          ]}
        >
          <View style={[styles.whatsappIcon, { backgroundColor: colors.gold }]}>
            <Feather name="message-circle" size={20} color={colors.ink} />
          </View>
          <View style={styles.whatsappCopy}>
            <Text style={[styles.whatsappEyebrow, { color: colors.sand }]}>DETAIL SUDAH SIAP?</Text>
            <Text style={[styles.whatsappTitle, { color: colors.cream }]}>Kirim detail ke WhatsApp</Text>
          </View>
          <Feather name="arrow-up-right" size={22} color={colors.gold} />
        </Pressable>
      </KeyboardAwareScrollViewCompat>

      <Modal visible={catalogVisible} animationType="slide" onRequestClose={() => setCatalogVisible(false)}>
        <View style={[styles.modalScreen, { backgroundColor: colors.ink, paddingTop: insets.top }]}>
          <View style={styles.modalHeader}>
            <View>
              <Text style={[styles.modalEyebrow, { color: colors.gold }]}>VISUAL CATALOG</Text>
              <Text style={[styles.modalTitle, { color: colors.cream }]}>Lihat katalog lengkap</Text>
            </View>
            <Pressable
              testID="close-catalog"
              onPress={() => setCatalogVisible(false)}
              style={[styles.closeButton, { backgroundColor: colors.burgundyDark }]}
            >
              <Feather name="x" size={22} color={colors.cream} />
            </Pressable>
          </View>
          <ScrollView
            contentContainerStyle={{ paddingBottom: insets.bottom + 32 }}
            maximumZoomScale={Platform.OS === 'ios' ? 3 : 1}
            minimumZoomScale={1}
            centerContent
          >
            <Image source={require('../../assets/images/catalog.png')} style={styles.catalogImage} resizeMode="contain" />
            <Text style={[styles.modalHint, { color: colors.sand }]}>Cubit gambar untuk memperbesar dan membaca rincian harga.</Text>
          </ScrollView>
        </View>
      </Modal>

      <Modal visible={guideVisible} animationType="slide" onRequestClose={() => setGuideVisible(false)}>
        <View style={[styles.modalScreen, { backgroundColor: colors.background, paddingTop: insets.top }]}>
          <View style={styles.modalHeader}>
            <View>
              <Text style={[styles.modalEyebrow, { color: colors.burgundy }]}>PANDUAN PEMESANAN</Text>
              <Text style={[styles.modalTitle, { color: colors.ink }]}>Cara pesan kaos custom</Text>
            </View>
            <Pressable
              testID="close-guide"
              onPress={() => setGuideVisible(false)}
              style={[styles.closeButton, { backgroundColor: colors.secondary }]}
            >
              <Feather name="x" size={22} color={colors.ink} />
            </Pressable>
          </View>

          <ScrollView
            showsVerticalScrollIndicator={false}
            contentContainerStyle={[styles.guideContent, { paddingBottom: insets.bottom + 30 }]}
          >
            <Text style={[styles.guideIntro, { color: colors.mutedForeground }]}>
              Siapkan detail di bawah ini agar tim D’Zahwa bisa membantu lebih cepat.
            </Text>

            {[
              'Kirim foto, logo, tulisan, atau ceritakan desain yang Anda inginkan.',
               'Pilih posisi desain: depan, belakang, atau keduanya.',
              'Sebutkan warna kaos, ukuran, dan jumlah untuk setiap ukuran.',
              'Beri tahu kapan kaos dibutuhkan dan kota tujuan pengiriman.',
              'Kami akan mengirim rincian desain, harga, ongkir, dan perkiraan waktu pengerjaan.',
              'Periksa semua rincian. Pesanan diproses setelah desain disetujui dan pembayaran diselesaikan sesuai kesepakatan.',
            ].map((step, index) => (
              <View key={step} style={styles.stepRow}>
                <View style={[styles.stepBadge, { backgroundColor: index === 0 ? colors.burgundy : colors.secondary }]}>
                  <Text style={[styles.stepNumber, { color: index === 0 ? colors.cream : colors.burgundy }]}>0{index + 1}</Text>
                </View>
                <Text style={[styles.stepText, { color: colors.ink }]}>{step}</Text>
              </View>
            ))}

            <View style={[styles.messageTemplate, { backgroundColor: colors.ink }]}>
              <View style={styles.templateHeader}>
                <View>
                  <Text style={[styles.templateEyebrow, { color: colors.gold }]}>FORMAT PESAN CEPAT</Text>
                  <Text style={[styles.templateTitle, { color: colors.cream }]}>Kirim detail ini ke admin</Text>
                </View>
                <Feather name="edit-3" size={19} color={colors.gold} />
              </View>
              <Text style={[styles.templateText, { color: colors.sand }]}>
                Desain/tulisan:{'\n'}
                Posisi desain:{'\n'}
                Warna kaos:{'\n'}
                Ukuran dan jumlah:{'\n'}
                Tanggal dibutuhkan:{'\n'}
                Kota tujuan:
              </Text>
              <Pressable
                testID="guide-whatsapp-button"
                onPress={openTemplateWhatsApp}
                style={({ pressed }) => [
                  styles.templateButton,
                  { backgroundColor: colors.gold, opacity: pressed ? 0.8 : 1 },
                ]}
              >
                <Feather name="message-circle" size={18} color={colors.ink} />
                <Text style={[styles.templateButtonText, { color: colors.ink }]}>Buka WhatsApp Business</Text>
                <Feather name="arrow-up-right" size={18} color={colors.ink} />
              </Pressable>
               <Text style={[styles.phoneNumber, { color: colors.sand }]}>
                 {formatWhatsAppNumber(whatsappBusinessNumber)}
               </Text>
            </View>
          </ScrollView>
        </View>
      </Modal>

      <Modal visible={templatesVisible} animationType="slide" onRequestClose={() => setTemplatesVisible(false)}>
        <View style={[styles.modalScreen, { backgroundColor: colors.background, paddingTop: insets.top }]}>
          <View style={styles.modalHeader}>
            <View>
              <Text style={[styles.modalEyebrow, { color: colors.burgundy }]}>UNTUK ADMIN</Text>
              <Text style={[styles.modalTitle, { color: colors.ink }]}>Balasan cepat WhatsApp</Text>
            </View>
            <Pressable
              testID="close-templates"
              onPress={() => setTemplatesVisible(false)}
              style={[styles.closeButton, { backgroundColor: colors.secondary }]}
            >
              <Feather name="x" size={22} color={colors.ink} />
            </Pressable>
          </View>

          <ScrollView
            showsVerticalScrollIndicator={false}
            contentContainerStyle={[styles.templateContent, { paddingBottom: insets.bottom + 30 }]}
          >
            <Text style={[styles.guideIntro, { color: colors.mutedForeground }]}>
              Pilih pintasan, ubah bagian dalam kurung siku bila perlu, lalu tekan lama teks untuk menyalin.
            </Text>
            {templateStorageError ? (
              <Text
                accessibilityRole="alert"
                testID="template-storage-error"
                style={[styles.templateStorageError, { color: colors.burgundy }]}
              >
                {templateStorageError}
              </Text>
            ) : null}

            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.templateChips}>
              {quickReplies.map((reply) => {
                const isActive = reply.id === selectedTemplate.id;
                return (
                  <Pressable
                    key={reply.id}
                    testID={`template-${reply.id}`}
                    onPress={() => {
                      Haptics.selectionAsync();
                      setSelectedTemplateId(reply.id);
                    }}
                    style={({ pressed }) => [
                      styles.templateChip,
                      {
                        backgroundColor: isActive ? colors.burgundy : colors.card,
                        borderColor: isActive ? colors.burgundy : colors.border,
                        opacity: pressed ? 0.75 : 1,
                      },
                    ]}
                  >
                    <Text style={[styles.templateChipShortcut, { color: isActive ? colors.gold : colors.burgundy }]}>{reply.shortcut}</Text>
                    <Text style={[styles.templateChipTitle, { color: isActive ? colors.cream : colors.ink }]}>{reply.title}</Text>
                  </Pressable>
                );
              })}
            </ScrollView>

            <View style={[styles.editorCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
              <View style={styles.editorHeader}>
                <View>
                  <Text style={[styles.editorShortcut, { color: colors.burgundy }]}>{selectedTemplate.shortcut}</Text>
                  <Text style={[styles.editorTitle, { color: colors.ink }]}>{selectedTemplate.title}</Text>
                </View>
                <Feather name="edit-3" size={18} color={colors.burgundy} />
              </View>
              <TextInput
                testID="template-editor"
                multiline
                value={templateDrafts[selectedTemplate.id]}
                onChangeText={(value) =>
                  setTemplateDrafts((drafts) => ({ ...drafts, [selectedTemplate.id]: value }))
                }
                textAlignVertical="top"
                selectionColor={colors.burgundy}
                style={[styles.templateEditor, { color: colors.ink, borderColor: colors.border }]}
              />
              <Text style={[styles.editorHint, { color: colors.mutedForeground }]}>
                Placeholder seperti [isi], [ongkir], dan [nomor resi] bisa diganti sebelum dikirim.
              </Text>
              <View style={styles.restoreRow}>
                <Pressable
                  testID="restore-selected-template"
                  onPress={restoreSelectedTemplate}
                  style={({ pressed }) => [
                    styles.restoreButton,
                    { borderColor: colors.border, backgroundColor: colors.background, opacity: pressed ? 0.72 : 1 },
                  ]}
                >
                  <Feather name="rotate-ccw" size={15} color={colors.burgundy} />
                  <Text style={[styles.restoreButtonText, { color: colors.burgundy }]}>Pulihkan ini</Text>
                </Pressable>
                <Pressable
                  testID="restore-all-templates"
                  onPress={restoreAllTemplates}
                  style={({ pressed }) => [
                    styles.restoreButton,
                    { borderColor: colors.border, backgroundColor: colors.background, opacity: pressed ? 0.72 : 1 },
                  ]}
                >
                  <Feather name="refresh-cw" size={15} color={colors.burgundy} />
                  <Text style={[styles.restoreButtonText, { color: colors.burgundy }]}>Pulihkan semua</Text>
                </Pressable>
              </View>
            </View>

            <Pressable
              testID="send-template-whatsapp-button"
              onPress={sendTemplateToWhatsApp}
              style={({ pressed }) => [
                styles.sendTemplateButton,
                { backgroundColor: colors.gold, opacity: pressed ? 0.82 : 1 },
              ]}
            >
              <Feather name="message-circle" size={18} color={colors.ink} />
              <Text style={[styles.sendTemplateButtonText, { color: colors.ink }]}>Kirim ke WhatsApp Business</Text>
              <Feather name="arrow-up-right" size={18} color={colors.ink} />
            </Pressable>

            <Pressable
              testID="share-template-button"
              onPress={() => {
                void shareTemplate();
              }}
              style={({ pressed }) => [
                styles.shareButton,
                { backgroundColor: colors.ink, opacity: pressed ? 0.82 : 1 },
              ]}
            >
              <Feather name="share-2" size={18} color={colors.gold} />
              <Text style={[styles.shareButtonText, { color: colors.cream }]}>Bagikan template</Text>
              <Feather name="arrow-up-right" size={18} color={colors.gold} />
            </Pressable>
            <Text style={[styles.shareHint, { color: colors.mutedForeground }]}>
              Jika WhatsApp belum tersedia, tombol kirim otomatis membuka menu bagikan perangkat.
            </Text>
          </ScrollView>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  content: { paddingHorizontal: 20, gap: 22 },
  topBar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  topActions: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  brandLockup: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  brandLogo: { width: 42, height: 42, borderRadius: 14 },
  brandName: { fontFamily: 'Inter_700Bold', fontSize: 20, letterSpacing: -0.8 },
  brandCaption: { fontFamily: 'Inter_700Bold', fontSize: 8, letterSpacing: 2.3, marginTop: 2 },
  iconButton: { width: 42, height: 42, borderRadius: 15, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  guidePill: { height: 42, borderRadius: 15, paddingHorizontal: 11, flexDirection: 'row', alignItems: 'center', gap: 5 },
  guidePillText: { fontFamily: 'Inter_600SemiBold', fontSize: 11 },
  welcomeCard: { minHeight: 192, borderRadius: 28, padding: 22, flexDirection: 'row', overflow: 'hidden' },
  welcomeCopy: { flex: 1, paddingRight: 14, justifyContent: 'space-between' },
  welcomeEyebrow: { fontFamily: 'Inter_700Bold', fontSize: 10, letterSpacing: 1.4 },
  welcomeTitle: { fontFamily: 'Inter_700Bold', fontSize: 28, lineHeight: 32, color: '#F8F3ED', letterSpacing: -1.2, maxWidth: 280 },
  welcomeDescription: { fontFamily: 'Inter_400Regular', fontSize: 12, lineHeight: 18, maxWidth: 245 },
  welcomeMark: { width: 52, height: 52, borderRadius: 18, alignItems: 'center', justifyContent: 'center', alignSelf: 'flex-end' },
  sectionHeading: { flexDirection: 'row', alignItems: 'flex-end', justifyContent: 'space-between' },
  sectionEyebrow: { fontFamily: 'Inter_700Bold', fontSize: 10, letterSpacing: 1.4, marginBottom: 5 },
  sectionTitle: { fontFamily: 'Inter_700Bold', fontSize: 22, letterSpacing: -0.8 },
  sectionCount: { fontFamily: 'Inter_500Medium', fontSize: 11, marginBottom: 3 },
  categoryRow: { flexDirection: 'row', gap: 12 },
  categoryCard: { flex: 1, minHeight: 148, borderRadius: 22, borderWidth: 1, padding: 14, justifyContent: 'space-between' },
  categoryIcon: { width: 38, height: 38, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
  categoryEyebrow: { fontFamily: 'Inter_600SemiBold', fontSize: 10, marginTop: 9 },
  categoryName: { fontFamily: 'Inter_700Bold', fontSize: 16, letterSpacing: -0.4 },
  categoryArrow: { position: 'absolute', right: 14, bottom: 14 },
  detailHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', gap: 12 },
  detailTitleWrap: { flex: 1 },
  detailEyebrow: { fontFamily: 'Inter_700Bold', fontSize: 10, letterSpacing: 1.2, marginBottom: 4 },
  detailTitle: { fontFamily: 'Inter_700Bold', fontSize: 25, letterSpacing: -0.9 },
  detailDescription: { fontFamily: 'Inter_400Regular', fontSize: 12, lineHeight: 17, marginTop: 5 },
  priceNote: { borderRadius: 12, paddingHorizontal: 10, paddingVertical: 8, flexDirection: 'row', alignItems: 'center', gap: 5 },
  priceNoteText: { fontFamily: 'Inter_600SemiBold', fontSize: 10 },
  sizeRow: { gap: 8, paddingRight: 20 },
  sizeChip: { paddingHorizontal: 15, paddingVertical: 10, borderRadius: 13, borderWidth: 1 },
  sizeText: { fontFamily: 'Inter_600SemiBold', fontSize: 12 },
  itemsList: { gap: 9 },
  itemRow: { minHeight: 74, borderRadius: 17, borderWidth: 1, padding: 11, flexDirection: 'row', alignItems: 'center', gap: 11 },
  itemNumber: { width: 38, height: 38, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
  itemNumberText: { fontFamily: 'Inter_700Bold', fontSize: 12 },
  itemCopy: { flex: 1 },
  itemName: { fontFamily: 'Inter_600SemiBold', fontSize: 13, lineHeight: 18 },
  itemMeta: { fontFamily: 'Inter_400Regular', fontSize: 10, marginTop: 3 },
  itemPriceWrap: { alignItems: 'flex-end', gap: 4 },
  itemPrice: { fontFamily: 'Inter_700Bold', fontSize: 12, textAlign: 'right' },
  guideCard: { minHeight: 82, borderRadius: 20, padding: 12, flexDirection: 'row', alignItems: 'center', gap: 11 },
  adminCard: { minHeight: 82, borderRadius: 20, borderWidth: 1, padding: 12, flexDirection: 'row', alignItems: 'center', gap: 11 },
  adminIcon: { width: 43, height: 43, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },
  guideIcon: { width: 43, height: 43, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },
  guideCopy: { flex: 1 },
  guideEyebrow: { fontFamily: 'Inter_700Bold', fontSize: 9, letterSpacing: 1.15 },
  guideTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 14, marginTop: 3 },
  guideDescription: { fontFamily: 'Inter_400Regular', fontSize: 10, marginTop: 3 },
  orderForm: { borderRadius: 23, borderWidth: 1, padding: 16, gap: 18 },
  formHeading: { flexDirection: 'row', alignItems: 'flex-start', gap: 12 },
  formHeadingCopy: { flex: 1 },
  formTitle: { fontFamily: 'Inter_700Bold', fontSize: 21, letterSpacing: -0.7 },
  formDescription: { fontFamily: 'Inter_400Regular', fontSize: 11, lineHeight: 16, marginTop: 5 },
  draftStatusRow: { flexDirection: 'row', alignItems: 'center', gap: 5, marginTop: 7 },
  draftStatusText: { fontFamily: 'Inter_600SemiBold', fontSize: 10 },
  formNumber: { width: 38, height: 38, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
  formNumberText: { fontFamily: 'Inter_700Bold', fontSize: 12 },
  fieldGroup: { gap: 7 },
  fieldRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 10 },
  halfField: { flex: 1, minWidth: 0 },
  fieldLabel: { fontFamily: 'Inter_600SemiBold', fontSize: 12 },
  fieldHint: { fontFamily: 'Inter_400Regular', fontSize: 10, lineHeight: 14 },
  textInput: { minHeight: 46, borderRadius: 13, borderWidth: 1, paddingHorizontal: 12, paddingVertical: 11, fontFamily: 'Inter_400Regular', fontSize: 12 },
  designInput: { minHeight: 82, lineHeight: 18 },
  compactInput: { height: 46, paddingVertical: 0 },
  optionRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  colorOptionRow: { gap: 8, paddingRight: 20 },
  optionChip: { borderRadius: 12, borderWidth: 1, paddingHorizontal: 12, paddingVertical: 9 },
  optionText: { fontFamily: 'Inter_600SemiBold', fontSize: 11 },
  selectedPrintCard: { minHeight: 62, borderRadius: 14, borderWidth: 1, padding: 10, flexDirection: 'row', alignItems: 'center', gap: 10 },
  selectedPrintIcon: { width: 36, height: 36, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  selectedPrintCopy: { flex: 1 },
  selectedPrintName: { fontFamily: 'Inter_700Bold', fontSize: 12, marginBottom: 3 },
  sizeQuantityList: { gap: 8 },
  sizeQuantityRow: { minHeight: 56, borderRadius: 14, borderWidth: 1, padding: 9, flexDirection: 'row', alignItems: 'center', gap: 10 },
  sizeQuantityCopy: { flex: 1 },
  sizeQuantitySize: { fontFamily: 'Inter_700Bold', fontSize: 12 },
  sizeQuantityPrice: { fontFamily: 'Inter_400Regular', fontSize: 10, marginTop: 3 },
  sizeQuantityInput: { width: 64, height: 38, borderRadius: 11, borderWidth: 1, paddingHorizontal: 8, textAlign: 'center', fontFamily: 'Inter_700Bold', fontSize: 13 },
  estimateCard: { borderRadius: 18, padding: 14 },
  estimateTopRow: { flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between' },
  estimateEyebrow: { fontFamily: 'Inter_700Bold', fontSize: 9, letterSpacing: 1.2 },
  estimateQuantity: { fontFamily: 'Inter_500Medium', fontSize: 10, marginTop: 4 },
  estimateTotal: { fontFamily: 'Inter_700Bold', fontSize: 24, letterSpacing: -0.8, marginTop: 13 },
  estimateNote: { fontFamily: 'Inter_400Regular', fontSize: 10, lineHeight: 15, marginTop: 4 },
  resetDraftButton: { minHeight: 43, borderRadius: 13, borderWidth: 1, paddingHorizontal: 12, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 7 },
  resetDraftText: { fontFamily: 'Inter_600SemiBold', fontSize: 11 },
  selectedValue: { minHeight: 46, borderRadius: 13, borderWidth: 1, paddingHorizontal: 11, flexDirection: 'row', alignItems: 'center', gap: 6 },
  selectedValueText: { fontFamily: 'Inter_700Bold', fontSize: 12 },
  whatsappButton: { minHeight: 73, borderRadius: 21, padding: 12, paddingRight: 16, flexDirection: 'row', alignItems: 'center', gap: 11 },
  whatsappIcon: { width: 44, height: 44, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },
  whatsappCopy: { flex: 1 },
  whatsappEyebrow: { fontFamily: 'Inter_700Bold', fontSize: 9, letterSpacing: 1.2 },
  whatsappTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 14, marginTop: 3 },
  modalScreen: { flex: 1, paddingHorizontal: 18 },
  modalHeader: { paddingVertical: 18, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  modalEyebrow: { fontFamily: 'Inter_700Bold', fontSize: 10, letterSpacing: 1.5 },
  modalTitle: { fontFamily: 'Inter_700Bold', fontSize: 22, marginTop: 4, letterSpacing: -0.6 },
  closeButton: { width: 42, height: 42, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },
  catalogImage: { width: '100%', height: 540, marginTop: 10 },
  modalHint: { textAlign: 'center', fontFamily: 'Inter_400Regular', fontSize: 12, lineHeight: 18, paddingHorizontal: 28, marginTop: 4 },
  guideContent: { gap: 13 },
  guideIntro: { fontFamily: 'Inter_400Regular', fontSize: 13, lineHeight: 20, marginBottom: 4 },
  stepRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 12, paddingVertical: 2 },
  stepBadge: { width: 36, height: 36, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  stepNumber: { fontFamily: 'Inter_700Bold', fontSize: 11 },
  stepText: { flex: 1, fontFamily: 'Inter_500Medium', fontSize: 13, lineHeight: 19, paddingTop: 7 },
  messageTemplate: { borderRadius: 24, padding: 18, marginTop: 8 },
  templateHeader: { flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between' },
  templateEyebrow: { fontFamily: 'Inter_700Bold', fontSize: 9, letterSpacing: 1.35 },
  templateTitle: { fontFamily: 'Inter_700Bold', fontSize: 19, marginTop: 4, letterSpacing: -0.4 },
  templateText: { fontFamily: 'Inter_400Regular', fontSize: 12, lineHeight: 21, marginTop: 18 },
  templateButton: { minHeight: 48, borderRadius: 15, paddingHorizontal: 13, flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 17 },
  templateButtonText: { flex: 1, fontFamily: 'Inter_700Bold', fontSize: 12 },
  phoneNumber: { fontFamily: 'Inter_500Medium', fontSize: 11, textAlign: 'center', marginTop: 11 },
  templateContent: { gap: 14 },
  templateStorageError: { fontFamily: 'Inter_600SemiBold', fontSize: 11, lineHeight: 16 },
  templateChips: { gap: 8, paddingRight: 20 },
  templateChip: { minWidth: 108, maxWidth: 132, minHeight: 67, borderRadius: 15, borderWidth: 1, padding: 10, justifyContent: 'space-between' },
  templateChipShortcut: { fontFamily: 'Inter_700Bold', fontSize: 11 },
  templateChipTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 11, lineHeight: 14 },
  editorCard: { borderRadius: 21, borderWidth: 1, padding: 14 },
  editorHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 10 },
  editorShortcut: { fontFamily: 'Inter_700Bold', fontSize: 11, letterSpacing: 0.4 },
  editorTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 15, marginTop: 3 },
  templateEditor: { minHeight: 245, borderWidth: 1, borderRadius: 14, padding: 12, fontFamily: 'Inter_400Regular', fontSize: 13, lineHeight: 20 },
  editorHint: { fontFamily: 'Inter_400Regular', fontSize: 10, lineHeight: 15, marginTop: 9 },
  restoreRow: { flexDirection: 'row', gap: 8, marginTop: 12 },
  restoreButton: { flex: 1, minHeight: 40, borderRadius: 12, borderWidth: 1, paddingHorizontal: 9, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6 },
  restoreButtonText: { fontFamily: 'Inter_600SemiBold', fontSize: 10 },
  sendTemplateButton: { minHeight: 51, borderRadius: 16, paddingHorizontal: 15, flexDirection: 'row', alignItems: 'center', gap: 9 },
  sendTemplateButtonText: { flex: 1, fontFamily: 'Inter_700Bold', fontSize: 13 },
  shareButton: { minHeight: 51, borderRadius: 16, paddingHorizontal: 15, flexDirection: 'row', alignItems: 'center', gap: 9 },
  shareButtonText: { flex: 1, fontFamily: 'Inter_700Bold', fontSize: 13 },
  shareHint: { fontFamily: 'Inter_400Regular', fontSize: 10, lineHeight: 15, textAlign: 'center', paddingHorizontal: 18 },
});

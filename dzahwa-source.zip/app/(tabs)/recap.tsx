import AsyncStorage from '@react-native-async-storage/async-storage';
import { Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { useCallback, useMemo, useState } from 'react';
import { useFocusEffect } from 'expo-router';
import {
  Alert,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';

type SaleRecord = {
  id: string;
  date: string;
  productType: string;
  quantity: number;
  amount: number;
};

const SALES_STORAGE_KEY = '@dzahwa-collections/sales-records';

const formatRupiah = (value: number) => `Rp${value.toLocaleString('id-ID')}`;

const formatDate = (value: string) =>
  new Date(value).toLocaleDateString('id-ID', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });

const isSaleRecord = (value: unknown): value is SaleRecord => {
  if (typeof value !== 'object' || value === null) {
    return false;
  }

  const record = value as Partial<SaleRecord>;
  return (
    typeof record.id === 'string' &&
    typeof record.date === 'string' &&
    typeof record.productType === 'string' &&
    typeof record.quantity === 'number' &&
    typeof record.amount === 'number' &&
    Number.isInteger(record.quantity) &&
    record.quantity > 0 &&
    Number.isInteger(record.amount) &&
    record.amount > 0
  );
};

export default function RecapScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [records, setRecords] = useState<SaleRecord[]>([]);
  const [productType, setProductType] = useState('');
  const [quantity, setQuantity] = useState('');
  const [amount, setAmount] = useState('');
  const [recordsLoaded, setRecordsLoaded] = useState(false);

  const loadRecords = useCallback(async () => {
    try {
      const stored = await AsyncStorage.getItem(SALES_STORAGE_KEY);
      if (!stored) {
        setRecords([]);
        return;
      }

      const parsed: unknown = JSON.parse(stored);
      if (Array.isArray(parsed)) {
        setRecords(parsed.filter(isSaleRecord));
      }
    } catch (error) {
      console.warn('Tidak dapat memuat rekapan penjualan.', error);
    } finally {
      setRecordsLoaded(true);
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      void loadRecords();
    }, [loadRecords]),
  );

  const stats = useMemo(() => {
    const productTypes = new Set(
      records.map((record) => record.productType.trim().toLocaleLowerCase('id-ID')),
    );

    return {
      transactions: records.length,
      shirts: records.reduce((total, record) => total + record.quantity, 0),
      revenue: records.reduce((total, record) => total + record.amount, 0),
      types: productTypes.size,
    };
  }, [records]);

  const saveRecords = async (nextRecords: SaleRecord[]) => {
    await AsyncStorage.setItem(SALES_STORAGE_KEY, JSON.stringify(nextRecords));
    setRecords(nextRecords);
  };

  const addSale = async () => {
    const trimmedType = productType.trim();
    const parsedQuantity = Number.parseInt(quantity, 10);
    const parsedAmount = Number.parseInt(amount, 10);

    if (
      trimmedType.length < 2 ||
      !Number.isInteger(parsedQuantity) ||
      parsedQuantity < 1 ||
      !Number.isInteger(parsedAmount) ||
      parsedAmount < 1
    ) {
      Alert.alert(
        'Lengkapi data penjualan',
        'Isi jenis kaos, jumlah minimal 1, dan nominal penjualan yang valid.',
      );
      return;
    }

    const newRecord: SaleRecord = {
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      date: new Date().toISOString(),
      productType: trimmedType,
      quantity: parsedQuantity,
      amount: parsedAmount,
    };

    try {
      await saveRecords([newRecord, ...records]);
      setProductType('');
      setQuantity('');
      setAmount('');
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      Alert.alert('Penjualan tersimpan', 'Angka rekapan sudah diperbarui.');
    } catch (error) {
      console.warn('Tidak dapat menyimpan penjualan.', error);
      Alert.alert('Penjualan belum tersimpan', 'Coba lagi setelah penyimpanan perangkat tersedia.');
    }
  };

  const removeSale = (record: SaleRecord) => {
    Alert.alert(
      'Hapus catatan ini?',
      `${record.productType} · ${record.quantity} kaos · ${formatRupiah(record.amount)}`,
      [
        { text: 'Batal', style: 'cancel' },
        {
          text: 'Hapus',
          style: 'destructive',
          onPress: () => {
            void saveRecords(records.filter((item) => item.id !== record.id)).catch((error) => {
              console.warn('Tidak dapat menghapus catatan penjualan.', error);
              Alert.alert('Catatan belum terhapus', 'Coba lagi.');
            });
          },
        },
      ],
    );
  };

  const statCards = [
    { label: 'Penjualan', value: stats.transactions.toString(), detail: 'transaksi', icon: 'shopping-bag' as const, tone: 'burgundy' },
    { label: 'Kaos terjual', value: stats.shirts.toString(), detail: 'pcs', icon: 'package' as const, tone: 'gold' },
    { label: 'Uang masuk', value: formatRupiah(stats.revenue), detail: 'total tercatat', icon: 'credit-card' as const, tone: 'ink' },
    { label: 'Jenis kaos', value: stats.types.toString(), detail: 'jenis berbeda', icon: 'layers' as const, tone: 'secondary' },
  ];

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      <KeyboardAwareScrollViewCompat
        contentContainerStyle={[
          styles.content,
          { paddingTop: insets.top + 18, paddingBottom: insets.bottom + 96 },
        ]}
        bottomOffset={24}
        keyboardDismissMode="interactive"
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.header}>
          <View style={styles.headerCopy}>
            <Text style={[styles.eyebrow, { color: colors.burgundy }]}>RUANG PEMILIK</Text>
            <Text style={[styles.title, { color: colors.ink }]}>Rekapan penjualan</Text>
            <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
              Pantau transaksi, jumlah kaos, uang masuk, dan jenis produk.
            </Text>
          </View>
          <View style={[styles.headerIcon, { backgroundColor: colors.ink }]}>
            <Feather name="bar-chart-2" size={21} color={colors.gold} />
          </View>
        </View>

        <View style={styles.statsGrid}>
          {statCards.map((card) => {
            const isBurgundy = card.tone === 'burgundy';
            const isGold = card.tone === 'gold';
            const isInk = card.tone === 'ink';
            const backgroundColor = isBurgundy
              ? colors.burgundy
              : isGold
                ? colors.gold
                : isInk
                  ? colors.ink
                  : colors.secondary;
            const foregroundColor = isBurgundy || isInk ? colors.cream : colors.ink;
            const mutedColor = isBurgundy || isInk ? colors.sand : colors.mutedForeground;

            return (
              <View key={card.label} style={[styles.statCard, { backgroundColor }]}>
                <View style={[styles.statIcon, { backgroundColor: isBurgundy || isInk ? colors.burgundyDark : colors.cream }]}>
                  <Feather name={card.icon} size={16} color={isBurgundy || isInk ? colors.gold : colors.burgundy} />
                </View>
                <Text style={[styles.statLabel, { color: mutedColor }]}>{card.label}</Text>
                <Text style={[styles.statValue, { color: foregroundColor }]} numberOfLines={1} adjustsFontSizeToFit>
                  {card.value}
                </Text>
                <Text style={[styles.statDetail, { color: mutedColor }]}>{card.detail}</Text>
              </View>
            );
          })}
        </View>

        <View style={[styles.formCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={styles.sectionHeader}>
            <View style={styles.sectionCopy}>
              <Text style={[styles.eyebrow, { color: colors.burgundy }]}>CATAT PENJUALAN</Text>
              <Text style={[styles.sectionTitle, { color: colors.ink }]}>Tambah transaksi</Text>
              <Text style={[styles.sectionText, { color: colors.mutedForeground }]}>
                Satu catatan bisa berisi beberapa kaos dari jenis yang sama.
              </Text>
            </View>
            <View style={[styles.stepBadge, { backgroundColor: colors.secondary }]}>
              <Text style={[styles.stepNumber, { color: colors.burgundy }]}>01</Text>
            </View>
          </View>

          <View style={styles.fieldGroup}>
            <Text style={[styles.fieldLabel, { color: colors.ink }]}>Jenis kaos</Text>
            <TextInput
              testID="sale-product-type-input"
              value={productType}
              onChangeText={setProductType}
              placeholder="Contoh: Kaos Dewasa - S"
              placeholderTextColor={colors.mutedForeground}
              style={[styles.input, { color: colors.ink, borderColor: colors.border, backgroundColor: colors.background }]}
            />
          </View>

          <View style={styles.fieldRow}>
            <View style={[styles.fieldGroup, styles.halfField]}>
              <Text style={[styles.fieldLabel, { color: colors.ink }]}>Jumlah kaos</Text>
              <TextInput
                testID="sale-quantity-input"
                value={quantity}
                onChangeText={(value) => setQuantity(value.replace(/[^0-9]/g, ''))}
                placeholder="Contoh: 12"
                placeholderTextColor={colors.mutedForeground}
                keyboardType="number-pad"
                style={[styles.input, { color: colors.ink, borderColor: colors.border, backgroundColor: colors.background }]}
              />
            </View>
            <View style={[styles.fieldGroup, styles.halfField]}>
              <Text style={[styles.fieldLabel, { color: colors.ink }]}>Total uang</Text>
              <TextInput
                testID="sale-amount-input"
                value={amount}
                onChangeText={(value) => setAmount(value.replace(/[^0-9]/g, ''))}
                placeholder="Contoh: 850000"
                placeholderTextColor={colors.mutedForeground}
                keyboardType="number-pad"
                style={[styles.input, { color: colors.ink, borderColor: colors.border, backgroundColor: colors.background }]}
              />
            </View>
          </View>

          <Pressable
            testID="save-sale-button"
            onPress={() => {
              void addSale();
            }}
            style={({ pressed }) => [
              styles.saveButton,
              { backgroundColor: colors.burgundy, opacity: pressed ? 0.82 : 1 },
            ]}
          >
            <Feather name="plus-circle" size={18} color={colors.gold} />
            <Text style={[styles.saveButtonText, { color: colors.cream }]}>Simpan penjualan</Text>
            <Feather name="arrow-up-right" size={18} color={colors.gold} />
          </Pressable>
        </View>

        <View style={styles.listHeader}>
          <View>
            <Text style={[styles.eyebrow, { color: colors.burgundy }]}>RIWAYAT TERCATAT</Text>
            <Text style={[styles.listTitle, { color: colors.ink }]}>Penjualan terbaru</Text>
          </View>
          <Text style={[styles.count, { color: colors.mutedForeground }]}>{records.length} transaksi</Text>
        </View>

        {!recordsLoaded || records.length === 0 ? (
          <View style={[styles.emptyCard, { backgroundColor: colors.secondary }]}>
            <View style={[styles.emptyIcon, { backgroundColor: colors.cream }]}>
              <Feather name="clipboard" size={21} color={colors.burgundy} />
            </View>
            <Text style={[styles.emptyTitle, { color: colors.ink }]}>
              Belum ada penjualan tercatat
            </Text>
            <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>
              Tambahkan transaksi pertama untuk mulai melihat rekap bisnis Anda.
            </Text>
          </View>
        ) : (
          <View style={styles.recordsList}>
            {records.map((record) => (
              <View key={record.id} style={[styles.recordCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
                <View style={[styles.recordIcon, { backgroundColor: colors.secondary }]}>
                  <Feather name="shopping-bag" size={17} color={colors.burgundy} />
                </View>
                <View style={styles.recordCopy}>
                  <Text style={[styles.recordType, { color: colors.ink }]}>{record.productType}</Text>
                  <Text style={[styles.recordMeta, { color: colors.mutedForeground }]}>
                    {formatDate(record.date)} · {record.quantity} kaos
                  </Text>
                </View>
                <View style={styles.recordAmount}>
                  <Text style={[styles.recordPrice, { color: colors.burgundy }]}>{formatRupiah(record.amount)}</Text>
                  <Pressable
                    testID={`delete-sale-${record.id}`}
                    accessibilityLabel={`Hapus penjualan ${record.productType}`}
                    onPress={() => removeSale(record)}
                    hitSlop={8}
                  >
                    <Feather name="trash-2" size={15} color={colors.mutedForeground} />
                  </Pressable>
                </View>
              </View>
            ))}
          </View>
        )}
      </KeyboardAwareScrollViewCompat>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  content: { paddingHorizontal: 20, gap: 18 },
  header: { flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between' },
  headerCopy: { flex: 1, paddingRight: 12 },
  eyebrow: { fontFamily: 'Inter_700Bold', fontSize: 10, letterSpacing: 1.45, marginBottom: 5 },
  title: { fontFamily: 'Inter_700Bold', fontSize: 27, lineHeight: 31, letterSpacing: -1 },
  subtitle: { fontFamily: 'Inter_400Regular', fontSize: 12, lineHeight: 18, marginTop: 5 },
  headerIcon: { width: 44, height: 44, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },
  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  statCard: { width: '48.5%', minHeight: 135, borderRadius: 20, padding: 13 },
  statIcon: { width: 31, height: 31, borderRadius: 11, alignItems: 'center', justifyContent: 'center' },
  statLabel: { fontFamily: 'Inter_600SemiBold', fontSize: 10, marginTop: 11 },
  statValue: { fontFamily: 'Inter_700Bold', fontSize: 24, letterSpacing: -0.8, marginTop: 4 },
  statDetail: { fontFamily: 'Inter_400Regular', fontSize: 10, marginTop: 2 },
  formCard: { borderRadius: 22, borderWidth: 1, padding: 16, gap: 15 },
  sectionHeader: { flexDirection: 'row', alignItems: 'flex-start', gap: 12 },
  sectionCopy: { flex: 1 },
  sectionTitle: { fontFamily: 'Inter_700Bold', fontSize: 20, letterSpacing: -0.6 },
  sectionText: { fontFamily: 'Inter_400Regular', fontSize: 11, lineHeight: 16, marginTop: 4 },
  stepBadge: { width: 38, height: 38, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
  stepNumber: { fontFamily: 'Inter_700Bold', fontSize: 11 },
  fieldGroup: { gap: 7 },
  fieldRow: { flexDirection: 'row', gap: 10 },
  halfField: { flex: 1, minWidth: 0 },
  fieldLabel: { fontFamily: 'Inter_600SemiBold', fontSize: 12 },
  input: { minHeight: 46, borderRadius: 13, borderWidth: 1, paddingHorizontal: 12, fontFamily: 'Inter_400Regular', fontSize: 12 },
  saveButton: { minHeight: 51, borderRadius: 16, paddingHorizontal: 14, flexDirection: 'row', alignItems: 'center', gap: 9 },
  saveButtonText: { flex: 1, fontFamily: 'Inter_700Bold', fontSize: 13 },
  listHeader: { flexDirection: 'row', alignItems: 'flex-end', justifyContent: 'space-between' },
  listTitle: { fontFamily: 'Inter_700Bold', fontSize: 21, letterSpacing: -0.7 },
  count: { fontFamily: 'Inter_500Medium', fontSize: 10, marginBottom: 3 },
  emptyCard: { borderRadius: 20, padding: 18, alignItems: 'center' },
  emptyIcon: { width: 48, height: 48, borderRadius: 16, alignItems: 'center', justifyContent: 'center' },
  emptyTitle: { fontFamily: 'Inter_700Bold', fontSize: 14, marginTop: 11 },
  emptyText: { fontFamily: 'Inter_400Regular', fontSize: 11, lineHeight: 16, textAlign: 'center', marginTop: 4, maxWidth: 270 },
  recordsList: { gap: 9 },
  recordCard: { minHeight: 72, borderRadius: 17, borderWidth: 1, padding: 11, flexDirection: 'row', alignItems: 'center', gap: 10 },
  recordIcon: { width: 38, height: 38, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
  recordCopy: { flex: 1 },
  recordType: { fontFamily: 'Inter_600SemiBold', fontSize: 13 },
  recordMeta: { fontFamily: 'Inter_400Regular', fontSize: 10, marginTop: 4 },
  recordAmount: { alignItems: 'flex-end', gap: 6 },
  recordPrice: { fontFamily: 'Inter_700Bold', fontSize: 11 },
});